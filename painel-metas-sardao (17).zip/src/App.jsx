import { useState, useEffect, useCallback, useRef } from "react";

const SENHA_ADMIN = "sardao2025";
const BIN_ID = "6a46d989da38895dfe24e7bb";
const API_KEY = "$2a$10$FG67MsHOcP5UH1/1PePSlu40wF59QbQa0uBWWrPbRYeha94Unwafi";

const T = {
  pageBg:"#eff6ff", header:"#1e3a8a", headerSub:"rgba(255,255,255,0.65)",
  card:"#ffffff", cardBorder:"#bfdbfe", text:"#1e3a8a", textSub:"#3b82f6",
  muted:"#64748b", barBg:"#dbeafe", btn:"#2563eb", btnText:"#ffffff",
  btnOff:"#e0e7ff", btnOffText:"#3b82f6",
  green:"#16a34a", greenBg:"#dcfce7", greenText:"#166534",
  yellow:"#d97706", yellowBg:"#fef3c7", yellowText:"#92400e",
  red:"#dc2626", redBg:"#fee2e2", redText:"#991b1b", gold:"#f59e0b",
};

const MESES_CONFIG = [
  { id:"jul26", nome:"Julho 2026",    prazo:"2026-07-20", metaR:40000, metaPrato:35, metaSobre:50, metaSuco:150, nomePrato:"Mignon Gratinado" },
  { id:"ago26", nome:"Agosto 2026",   prazo:"2026-08-20", metaR:40000, metaPrato:35, metaSobre:50, metaSuco:150, nomePrato:"" },
  { id:"set26", nome:"Setembro 2026", prazo:"2026-09-20", metaR:40000, metaPrato:35, metaSobre:50, metaSuco:150, nomePrato:"" },
  { id:"out26", nome:"Outubro 2026",  prazo:"2026-10-20", metaR:40000, metaPrato:35, metaSobre:50, metaSuco:150, nomePrato:"" },
  { id:"nov26", nome:"Novembro 2026", prazo:"2026-11-20", metaR:40000, metaPrato:35, metaSobre:50, metaSuco:150, nomePrato:"" },
  { id:"dez26", nome:"Dezembro 2026", prazo:"2026-12-20", metaR:40000, metaPrato:35, metaSobre:50, metaSuco:150, nomePrato:"" },
];

const COLABS_PADRAO = [
  "Silvia","Felipe","Leandro","LG","Luís","Richard","Sarah","Sidmar","Zé","Thaís","Jocilene","Ale","Patrícia","Karen"
];

const dadosPadraoJul = [
  { id:1,  nome:"Silvia",   realizado:10600, prato:1,  costelinha:0, drink:0, sobremesa:1,  suco:4,  avaliacao:0 },
  { id:2,  nome:"Felipe",   realizado:7500,  prato:2,  costelinha:0, drink:0, sobremesa:0,  suco:38, avaliacao:0 },
  { id:3,  nome:"Leandro",  realizado:12600, prato:1,  costelinha:0, drink:0, sobremesa:1,  suco:29, avaliacao:0 },
  { id:4,  nome:"LG",       realizado:13200, prato:3,  costelinha:0, drink:0, sobremesa:2,  suco:30, avaliacao:0 },
  { id:5,  nome:"Luís",     realizado:10400, prato:0,  costelinha:0, drink:0, sobremesa:15, suco:13, avaliacao:0 },
  { id:6,  nome:"Richard",  realizado:5600,  prato:0,  costelinha:0, drink:0, sobremesa:1,  suco:4,  avaliacao:0 },
  { id:7,  nome:"Sarah",    realizado:10900, prato:0,  costelinha:0, drink:0, sobremesa:10, suco:47, avaliacao:0 },
  { id:8,  nome:"Sidmar",   realizado:16900, prato:0,  costelinha:0, drink:0, sobremesa:21, suco:41, avaliacao:0 },
  { id:9,  nome:"Zé",       realizado:19000, prato:1,  costelinha:0, drink:0, sobremesa:14, suco:24, avaliacao:0 },
  { id:10, nome:"Thaís",    realizado:10000, prato:0,  costelinha:0, drink:0, sobremesa:17, suco:37, avaliacao:0 },
  { id:11, nome:"Jocilene", realizado:0,     prato:2,  costelinha:0, drink:0, sobremesa:14, suco:6,  avaliacao:0 },
  { id:12, nome:"Ale",      realizado:0,     prato:0,  costelinha:0, drink:0, sobremesa:1,  suco:4,  avaliacao:0 },
  { id:13, nome:"Patrícia", realizado:0,     prato:0,  costelinha:0, drink:0, sobremesa:0,  suco:2,  avaliacao:0 },
  { id:14, nome:"Karen",    realizado:0,     prato:0,  costelinha:0, drink:0, sobremesa:0,  suco:9,  avaliacao:0 },
];

// Sistema de pontos — Mestre da Venda Consultiva
const calcPontos = (c) =>
  (c.prato||0)*4 + (c.costelinha||0)*3 + (c.drink||0)*2 + (c.suco||0)*1 + (c.sobremesa||0)*1;

const META_CAMPEAO = 50000;
const META_PONTOS  = 310;
const META_AVAL    = 25;

const colabsVazios = () => COLABS_PADRAO.map((nome, i) => ({
  id:i+1, nome, realizado:0, prato:0, costelinha:0, drink:0, sobremesa:0, suco:0, avaliacao:0
}));

const defaultData = {
  mesesConfig: MESES_CONFIG,
  meses: {
    jul26: { colabs: dadosPadraoJul, fechado: false },
    ago26: { colabs: colabsVazios(), fechado: false },
    set26: { colabs: colabsVazios(), fechado: false },
    out26: { colabs: colabsVazios(), fechado: false },
    nov26: { colabs: colabsVazios(), fechado: false },
    dez26: { colabs: colabsVazios(), fechado: false },
  }
};

const medal = ["🥇","🥈","🥉"];
const fmt = (v) => Number(v).toLocaleString("pt-BR", { style:"currency", currency:"BRL" });
const fmtPct = (v, meta) => meta ? Math.round((v/meta)*100) : 0;

const statusR = (v, meta) => {
  const p = fmtPct(v, meta);
  if (p >= 100) return { label:"✅ Bateu!", bar:T.green,  badge:{bg:T.greenBg,  text:T.greenText}  };
  if (p >= 80)  return { label:"⚡ Quase!", bar:T.yellow, badge:{bg:T.yellowBg, text:T.yellowText} };
  return             { label:"❌ Não bateu", bar:T.red,   badge:{bg:T.redBg,    text:T.redText}    };
};

// ─── COUNTDOWN ───────────────────────────────────────────────────────────────
function Countdown({ prazo }) {
  const [diff, setDiff] = useState(new Date(prazo) - new Date());
  useEffect(() => { const t = setInterval(() => setDiff(new Date(prazo) - new Date()), 1000); return () => clearInterval(t); }, [prazo]);
  if (diff <= 0) return <span style={{color:T.red,fontWeight:700,fontSize:12}}>Prazo encerrado!</span>;
  const parts = [
    {v:Math.floor(diff/86400000),l:"dias"},
    {v:Math.floor((diff%86400000)/3600000),l:"h"},
    {v:Math.floor((diff%3600000)/60000),l:"min"},
    {v:Math.floor((diff%60000)/1000),l:"seg"},
  ];
  return (
    <div style={{display:"flex",gap:5}}>
      {parts.map(({v,l}) => (
        <div key={l} style={{background:"rgba(255,255,255,0.15)",borderRadius:7,padding:"4px 8px",textAlign:"center",minWidth:36}}>
          <p style={{color:"#fff",fontSize:13,fontWeight:800,margin:0}}>{String(v).padStart(2,"0")}</p>
          <p style={{color:"rgba(255,255,255,0.6)",fontSize:8,margin:0}}>{l}</p>
        </div>
      ))}
    </div>
  );
}

// ─── RANKING TAB ─────────────────────────────────────────────────────────────
function RankingTab({ colabs, field, label, color, emoji, metaInd }) {
  const sorted = [...colabs].filter(c => c[field] > 0).sort((a,b) => b[field]-a[field]);
  const bateram = metaInd ? sorted.filter(c => c[field] >= metaInd).length : 0;
  if (sorted.length === 0) return <p style={{color:T.muted,padding:20}}>Nenhum dado ainda.</p>;
  return (
    <div>
      {metaInd && (
        <div style={{background:T.card,borderRadius:12,padding:"12px 18px",marginBottom:14,border:`1px solid ${T.cardBorder}`,display:"flex",gap:16,alignItems:"center",flexWrap:"wrap",boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
          <div>
            <p style={{color:T.muted,fontSize:10,margin:"0 0 2px",textTransform:"uppercase"}}>{emoji} Meta individual</p>
            <p style={{color:T.text,fontSize:15,fontWeight:700,margin:0}}>{metaInd} unidades</p>
          </div>
          <div style={{height:32,width:1,background:T.cardBorder}}/>
          <div>
            <p style={{color:T.muted,fontSize:10,margin:"0 0 2px",textTransform:"uppercase"}}>Bateram a meta</p>
            <p style={{color:T.green,fontSize:15,fontWeight:700,margin:0}}>{bateram} de {sorted.length}</p>
          </div>
        </div>
      )}
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        {sorted.map((c,i) => {
          const pct = metaInd ? Math.min(Math.round((c[field]/metaInd)*100),100) : null;
          const bateu = metaInd && c[field] >= metaInd;
          const falta = metaInd ? Math.max(0, metaInd - c[field]) : 0;
          const maxVal = sorted[0]?.[field] || 1;
          return (
            <div key={c.id} style={{background:T.card,borderRadius:12,padding:"12px 16px",border:bateu?`2px solid ${T.green}`:i===0?`2px solid ${color}`:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
              <div style={{display:"flex",alignItems:"center",gap:12}}>
                <span style={{fontSize:i<3?20:13,minWidth:28,textAlign:"center",color:i>=3?T.muted:undefined,fontWeight:700}}>{i<3?medal[i]:`${i+1}º`}</span>
                <span style={{color:T.text,fontSize:14,fontWeight:700,minWidth:90}}>{c.nome}</span>
                <div style={{flex:1}}>
                  {metaInd && <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                    <span style={{color:T.muted,fontSize:10}}>{c[field]} / {metaInd}</span>
                    <span style={{color:bateu?T.green:color,fontSize:11,fontWeight:700}}>{pct}%</span>
                  </div>}
                  <div style={{background:T.barBg,borderRadius:99,height:7,overflow:"hidden"}}>
                    <div style={{height:"100%",width:`${metaInd?pct:(c[field]/maxVal)*100}%`,background:bateu?T.green:color,borderRadius:99}}/>
                  </div>
                </div>
                <div style={{textAlign:"right",minWidth:60}}>
                  <span style={{color:bateu?T.green:color,fontSize:17,fontWeight:800}}>{c[field]}</span>
                  {bateu && <span style={{display:"block",color:T.green,fontSize:9,fontWeight:700}}>✅ Bateu!</span>}
                  {!bateu && metaInd && falta > 0 && <span style={{display:"block",color:T.muted,fontSize:9}}>falta {falta}</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── GRÁFICO SIMPLES (barras) ─────────────────────────────────────────────────
function BarChart({ data, color, height=120 }) {
  const max = Math.max(...data.map(d => d.valor), 1);
  return (
    <div style={{display:"flex",alignItems:"flex-end",gap:4,height,paddingTop:8}}>
      {data.map((d,i) => (
        <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
          <span style={{color:T.text,fontSize:9,fontWeight:700}}>{d.valor > 0 ? (typeof d.valor === 'number' && d.valor >= 1000 ? `${Math.round(d.valor/1000)}k` : d.valor) : ''}</span>
          <div style={{width:"100%",background:color,borderRadius:"4px 4px 0 0",height:`${(d.valor/max)*(height-24)}px`,minHeight:d.valor>0?4:0,transition:"height 0.4s"}}/>
          <span style={{color:T.muted,fontSize:8,textAlign:"center",lineHeight:1.2}}>{d.nome}</span>
        </div>
      ))}
    </div>
  );
}

// ─── ABA RELATÓRIOS ───────────────────────────────────────────────────────────
function Relatorios({ data }) {
  const [subTab, setSubTab] = useState("mensal");
  const [mesSel, setMesSel] = useState("jul26");

  const mesesFechados = data.mesesConfig.filter(m => data.meses[m.id]?.fechado || m.id === "jul26");
  const todosColabNomes = [...new Set(Object.values(data.meses).flatMap(m => m.colabs.map(c => c.nome)))].filter(Boolean);

  const subBtn = (key, lbl) => (
    <button onClick={() => setSubTab(key)} style={{padding:"6px 12px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:11,background:subTab===key?T.btn:T.btnOff,color:subTab===key?T.btnText:T.btnOffText}}>
      {lbl}
    </button>
  );

  // Dados do mês selecionado
  const cfgSel = data.mesesConfig.find(m => m.id === mesSel);
  const colabsSel = data.meses[mesSel]?.colabs || [];
  const sortedR = [...colabsSel].sort((a,b) => b.realizado - a.realizado);

  // Acumulado anual por colaborador
  const acumulado = todosColabNomes.map(nome => {
    let totalR = 0, mesesBateu = 0, totalPrato = 0, totalSobre = 0, totalSuco = 0;
    data.mesesConfig.forEach(m => {
      const c = data.meses[m.id]?.colabs.find(x => x.nome === nome);
      if (c) {
        totalR += c.realizado || 0;
        totalPrato += c.prato || 0;
        totalSobre += c.sobremesa || 0;
        totalSuco += c.suco || 0;
        if (c.realizado >= m.metaR) mesesBateu++;
      }
    });
    return { nome, totalR, mesesBateu, totalPrato, totalSobre, totalSuco };
  }).sort((a,b) => b.totalR - a.totalR);

  // Comparativo mês a mês (total realizado por mês)
  const comparativo = data.mesesConfig.map(m => ({
    nome: m.nome.split(" ")[0],
    valor: data.meses[m.id]?.colabs.reduce((s,c) => s + (c.realizado||0), 0) || 0
  }));

  return (
    <div>
      <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
        {subBtn("mensal",     "📋 Mensal")}
        {subBtn("acumulado",  "🏆 Acumulado Anual")}
        {subBtn("comparativo","📊 Comparativo Meses")}
      </div>

      {/* MENSAL */}
      {subTab === "mensal" && (
        <div>
          <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
            {data.mesesConfig.map(m => (
              <button key={m.id} onClick={() => setMesSel(m.id)} style={{padding:"6px 14px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:11,background:mesSel===m.id?T.btn:T.btnOff,color:mesSel===m.id?T.btnText:T.btnOffText}}>
                {m.nome.split(" ")[0]}
              </button>
            ))}
          </div>

          {cfgSel && (
            <>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))",gap:10,marginBottom:16}}>
                {[
                  {label:"Meta R$", valor:fmt(cfgSel.metaR), color:T.btn},
                  {label:"Total Realizado", valor:fmt(colabsSel.reduce((s,c)=>s+(c.realizado||0),0)), color:T.green},
                  {label:"Bateram meta", valor:`${colabsSel.filter(c=>c.realizado>=cfgSel.metaR).length} de ${colabsSel.length}`, color:T.gold},
                  {label:"Prato do Mês", valor:cfgSel.nomePrato||"—", color:"#f59e0b"},
                ].map(s => (
                  <div key={s.label} style={{background:T.card,borderRadius:10,padding:"10px 14px",border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                    <p style={{color:T.muted,fontSize:9,margin:"0 0 3px",textTransform:"uppercase"}}>{s.label}</p>
                    <p style={{color:s.color,fontSize:14,fontWeight:700,margin:0}}>{s.valor}</p>
                  </div>
                ))}
              </div>

              <div style={{background:T.card,borderRadius:12,padding:"14px 16px",marginBottom:14,border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                <p style={{color:T.muted,fontSize:11,margin:"0 0 10px",textTransform:"uppercase"}}>📊 Ranking de Vendas</p>
                <BarChart data={sortedR.map(c=>({nome:c.nome.split(" ")[0],valor:c.realizado}))} color={T.btn} />
              </div>

              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {sortedR.map((c,i) => {
                  const pct = fmtPct(c.realizado, cfgSel.metaR);
                  const s = statusR(c.realizado, cfgSel.metaR);
                  return (
                    <div key={c.id} style={{background:T.card,borderRadius:12,padding:"12px 16px",border:i===0?`2px solid ${T.gold}`:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                      <div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
                        <span style={{fontSize:i<3?20:13,minWidth:26,fontWeight:700,color:i>=3?T.muted:undefined}}>{i<3?medal[i]:`${i+1}º`}</span>
                        <span style={{color:T.text,fontSize:14,fontWeight:700,minWidth:80}}>{c.nome}</span>
                        <span style={{color:T.muted,fontSize:12,minWidth:90}}>{fmt(c.realizado)}</span>
                        <div style={{flex:1,minWidth:80}}>
                          <div style={{background:T.barBg,borderRadius:99,height:7,overflow:"hidden"}}>
                            <div style={{height:"100%",width:`${Math.min(pct,100)}%`,background:s.bar,borderRadius:99}}/>
                          </div>
                        </div>
                        <span style={{color:s.bar,fontSize:12,fontWeight:700,minWidth:36}}>{pct}%</span>
                        <span style={{background:s.badge.bg,color:s.badge.text,fontSize:10,fontWeight:600,padding:"2px 8px",borderRadius:99}}>{s.label}</span>
                      </div>
                      <div style={{display:"flex",gap:12,marginTop:8,paddingLeft:36}}>
                        <span style={{color:"#f59e0b",fontSize:11}}>⭐ {c.prato} pratos</span>
                        <span style={{color:"#a855f7",fontSize:11}}>🍮 {c.sobremesa} sobremesas</span>
                        <span style={{color:"#0ea5e9",fontSize:11}}>🍹 {c.suco} sucos</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      )}

      {/* ACUMULADO ANUAL */}
      {subTab === "acumulado" && (
        <div>
          <div style={{background:T.card,borderRadius:12,padding:"14px 16px",marginBottom:14,border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
            <p style={{color:T.muted,fontSize:11,margin:"0 0 10px",textTransform:"uppercase"}}>💰 Total Vendido no Ano</p>
            <BarChart data={acumulado.map(c=>({nome:c.nome.split(" ")[0],valor:c.totalR}))} color={T.btn} height={140} />
          </div>

          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {acumulado.map((c,i) => (
              <div key={c.nome} style={{background:T.card,borderRadius:12,padding:"13px 16px",border:i===0?`2px solid ${T.gold}`:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                <div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
                  <span style={{fontSize:i<3?20:13,minWidth:26,fontWeight:700,color:i>=3?T.muted:undefined}}>{i<3?medal[i]:`${i+1}º`}</span>
                  <span style={{color:T.text,fontSize:14,fontWeight:700,flex:1}}>{c.nome}</span>
                  <span style={{color:T.btn,fontSize:14,fontWeight:700}}>{fmt(c.totalR)}</span>
                  <span style={{background:T.greenBg,color:T.greenText,fontSize:11,fontWeight:700,padding:"2px 8px",borderRadius:99}}>🏆 {c.mesesBateu} {c.mesesBateu===1?"mês":"meses"} batidos</span>
                </div>
                <div style={{display:"flex",gap:12,marginTop:8,paddingLeft:36}}>
                  <span style={{color:"#f59e0b",fontSize:11}}>⭐ {c.totalPrato} pratos</span>
                  <span style={{color:"#a855f7",fontSize:11}}>🍮 {c.totalSobre} sobremesas</span>
                  <span style={{color:"#0ea5e9",fontSize:11}}>🍹 {c.totalSuco} sucos</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* COMPARATIVO MESES */}
      {subTab === "comparativo" && (
        <div>
          <div style={{background:T.card,borderRadius:12,padding:"16px",marginBottom:14,border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
            <p style={{color:T.muted,fontSize:11,margin:"0 0 12px",textTransform:"uppercase"}}>📈 Total Vendido por Mês (R$)</p>
            <BarChart data={comparativo} color={T.btn} height={160} />
          </div>

          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:10}}>
            {data.mesesConfig.map(m => {
              const colabs = data.meses[m.id]?.colabs || [];
              const total = colabs.reduce((s,c) => s+(c.realizado||0), 0);
              const bateram = colabs.filter(c => c.realizado >= m.metaR).length;
              return (
                <div key={m.id} style={{background:T.card,borderRadius:12,padding:"13px 16px",border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                  <p style={{color:T.text,fontSize:13,fontWeight:700,margin:"0 0 8px"}}>{m.nome}</p>
                  <p style={{color:T.muted,fontSize:10,margin:"0 0 2px",textTransform:"uppercase"}}>Total vendido</p>
                  <p style={{color:T.btn,fontSize:15,fontWeight:700,margin:"0 0 6px"}}>{fmt(total)}</p>
                  <p style={{color:T.green,fontSize:11,margin:0}}>✅ {bateram} de {colabs.length} bateram a meta</p>
                  {m.nomePrato && <p style={{color:"#f59e0b",fontSize:11,margin:"4px 0 0"}}>⭐ {m.nomePrato}</p>}
                  {data.meses[m.id]?.fechado && <span style={{background:T.greenBg,color:T.greenText,fontSize:9,fontWeight:700,padding:"1px 6px",borderRadius:99,marginTop:4,display:"inline-block"}}>✔ Fechado</span>}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── CONFIG MÊS (admin) ───────────────────────────────────────────────────────
function ConfigMes({ data, onSave }) {
  const [mesSel, setMesSel] = useState("ago26");
  const [cfg, setCfg] = useState(null);

  useEffect(() => {
    const found = data.mesesConfig.find(m => m.id === mesSel);
    setCfg(found ? {...found} : null);
  }, [mesSel, data.mesesConfig]);

  const salvarCfg = () => {
    const novosCfg = data.mesesConfig.map(m => m.id === mesSel ? cfg : m);
    onSave({ ...data, mesesConfig: novosCfg });
  };

  const inp = {width:"100%",background:T.pageBg,border:`1px solid ${T.cardBorder}`,borderRadius:7,color:T.text,fontSize:13,padding:"7px 10px",outline:"none",boxSizing:"border-box"};

  return (
    <div>
      <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
        {data.mesesConfig.filter(m => m.id !== "jul26").map(m => (
          <button key={m.id} onClick={() => setMesSel(m.id)} style={{padding:"6px 14px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:11,background:mesSel===m.id?T.btn:T.btnOff,color:mesSel===m.id?T.btnText:T.btnOffText}}>
            {m.nome.split(" ")[0]}
          </button>
        ))}
      </div>

      {cfg && (
        <div style={{background:T.card,borderRadius:12,padding:"18px",border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)",maxWidth:500}}>
          <p style={{color:T.text,fontSize:14,fontWeight:700,margin:"0 0 14px"}}>⚙️ Configurar {cfg.nome}</p>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            {[
              {key:"metaR",      label:"Meta em R$",          type:"number"},
              {key:"metaPrato",  label:"Meta Prato (unid.)",   type:"number"},
              {key:"metaSobre",  label:"Meta Sobremesa (unid.)",type:"number"},
              {key:"metaSuco",   label:"Meta Sucos (unid.)",    type:"number"},
              {key:"nomePrato",  label:"Nome do Prato do Mês",  type:"text", full:true},
              {key:"prazo",      label:"Prazo (data)",          type:"date", full:true},
            ].map(({key,label,type,full}) => (
              <div key={key} style={full?{gridColumn:"span 2"}:{}}>
                <p style={{color:T.muted,fontSize:10,margin:"0 0 3px",textTransform:"uppercase"}}>{label}</p>
                <input type={type} value={cfg[key]||""} onChange={e => setCfg({...cfg,[key]:type==="number"?Number(e.target.value):e.target.value})} style={inp} />
              </div>
            ))}
          </div>
          <button onClick={salvarCfg} style={{marginTop:14,background:T.btn,border:"none",borderRadius:9,color:"#fff",fontSize:13,fontWeight:700,padding:"9px 20px",cursor:"pointer"}}>
            💾 Salvar configurações
          </button>
        </div>
      )}
    </div>
  );
}

// ─── ABA LANÇAMENTO DE VENDAS ─────────────────────────────────────────────────
function AbaLancamento({ colabs, cfgAtiva, fechado, onFecharMes, onSalvarDireto, onSalvarBatch, onSomar, onAtualizarDesafio, addColab, removeColab, updateNome, fmt }) {
  const [subTab, setSubTab] = useState("editar");
  const [salvando, setSalvando] = useState(false);
  const [salvo, setSalvo] = useState(false);

  // Estado local como STRING para input funcionar sem resetar
  const [vals, setVals] = useState(() => {
    const v = {};
    colabs.forEach(c => { v[c.id] = String(c.realizado||0); });
    return v;
  });

  // Sincroniza quando dados externos mudam (após salvar no JSONbin)
  useEffect(() => {
    setVals(prev => {
      const novo = {...prev};
      colabs.forEach(c => {
        // Só sincroniza se o usuário não está editando (valor igual ao salvo)
        if (parseFloat(prev[c.id]||0) === (c.realizado||0)) {
          novo[c.id] = String(c.realizado||0);
        }
      });
      return novo;
    });
  }, [colabs]);

  const [dia, setDia] = useState("sab");
  const [novosSab, setNovosSab] = useState({});
  const [novosDom, setNovosDom] = useState({});

  const setVal = (id, campo, valor) => {
    // Guarda como string — não converte aqui para não resetar o campo
    setVals(prev => ({ ...prev, [id]: valor }));
  };

  const salvarEdicao = () => {
    setSalvando(true);
    // Monta mapa de todos os valores de uma vez e envia em batch
    const mapa = {};
    colabs.forEach(c => {
      const limpo = String(vals[c.id]||0).replace(",",".").replace(/[^0-9.]/g,"");
      mapa[c.id] = parseFloat(limpo) || 0;
    });
    // Chama onSalvarBatch com todos os valores de uma vez
    onSalvarBatch(mapa);
    setTimeout(() => {
      setSalvando(false);
      setSalvo(true);
      setTimeout(() => setSalvo(false), 3000);
    }, 600);
  };

  const salvarSoma = () => {
    setSalvando(true);
    colabs.forEach(c => {
      const vSab = novosSab[c.id] || 0;
      const vDom = novosDom[c.id] || 0;
      if (vSab > 0 || vDom > 0) {
        onSomar(c.id, vSab, vDom);
      }
    });
    setTimeout(() => {
      setSalvando(false);
      setSalvo(true);
      setNovosSab({});
      setNovosDom({});
      setTimeout(() => setSalvo(false), 3000);
    }, 600);
  };

  const subBtn = (key, lbl) => (
    <button onClick={() => { setSubTab(key); setSalvo(false); }}
      style={{padding:"7px 14px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:12,
        background:subTab===key?T.btn:T.btnOff, color:subTab===key?T.btnText:T.btnOffText, whiteSpace:"nowrap"}}>
      {lbl}
    </button>
  );

  const inp = {background:T.pageBg, border:`1.5px solid ${T.cardBorder}`, borderRadius:9,
    color:T.text, fontSize:14, padding:"10px 12px", outline:"none", width:"100%", boxSizing:"border-box",
    fontFamily:"inherit", transition:"border 0.2s"};

  return (
    <div>
      {!fechado && (
        <div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}>
          <button onClick={onFecharMes}
            style={{background:T.greenBg,border:`1px solid ${T.green}`,borderRadius:9,color:T.greenText,fontSize:12,fontWeight:700,padding:"7px 16px",cursor:"pointer"}}>
            ✔ Fechar {cfgAtiva?.nome}
          </button>
        </div>
      )}

      <div style={{background:T.card,borderRadius:10,padding:"8px 12px",display:"flex",gap:7,flexWrap:"wrap",marginBottom:14,border:`1px solid ${T.cardBorder}`}}>
        {subBtn("editar",    "✏️ Editar Valores")}
        {subBtn("somar",     "➕ Somar Vendas")}
        {subBtn("desafios",  "🏆 Desafios")}
        {subBtn("equipe",    "👥 Equipe")}
      </div>

      {salvo && (
        <div style={{background:T.greenBg,color:T.greenText,fontSize:13,fontWeight:700,borderRadius:10,padding:"10px 16px",marginBottom:12,textAlign:"center",border:`1px solid #86efac`}}>
          ✅ Valores salvos com sucesso!
        </div>
      )}

      {/* ── EDITAR VALORES DIRETO ── */}
      {subTab === "editar" && (
        <div>
          <div style={{background:"#fef3c7",borderRadius:10,padding:"10px 14px",marginBottom:14,border:"1px solid #fde68a"}}>
            <p style={{color:"#92400e",fontSize:12,fontWeight:600,margin:0}}>
              ✏️ Digite o valor <strong>total acumulado</strong> de cada garçom. O valor que você digitar <strong>substitui</strong> o atual.
            </p>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            {colabs.filter(c=>c.nome).map(c => {
              const valAtual = vals[c.id]?.realizado ?? c.realizado ?? 0;
              const mudou = valAtual !== (c.realizado||0);
              return (
                <div key={c.id} style={{background:T.card,borderRadius:12,padding:"14px 16px",
                  border:`2px solid ${mudou?"#f59e0b":T.cardBorder}`,
                  boxShadow:"0 1px 4px rgba(37,99,235,0.07)", transition:"border 0.2s"}}>
                  <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                    <div style={{width:36,height:36,borderRadius:99,background:mudou?"#f59e0b":T.btn,
                      display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                      <span style={{color:"#fff",fontSize:14,fontWeight:800}}>{c.nome[0]}</span>
                    </div>
                    <div style={{flex:1}}>
                      <p style={{color:T.text,fontSize:14,fontWeight:700,margin:"0 0 1px"}}>{c.nome}</p>
                      <p style={{color:T.muted,fontSize:11,margin:0}}>
                        Valor atual: <strong style={{color:T.btn}}>{fmt(c.realizado||0)}</strong>
                      </p>
                    </div>
                    {mudou && (
                      <div style={{textAlign:"right"}}>
                        <p style={{color:"#f59e0b",fontSize:10,margin:"0 0 1px",fontWeight:600}}>Novo valor</p>
                        <p style={{color:"#f59e0b",fontSize:13,fontWeight:800,margin:0}}>{fmt(valAtual)}</p>
                      </div>
                    )}
                  </div>
                  <input
                    type="number"
                    value={vals[c.id] ?? ""}
                    onChange={e => setVal(c.id, "realizado", e.target.value)}
                    placeholder={`Atual: ${c.realizado||0}`}
                    style={{...inp, borderColor: mudou?"#f59e0b":T.cardBorder}}
                  />
                  {mudou && (
                    <p style={{color:"#f59e0b",fontSize:11,fontWeight:600,margin:"6px 0 0"}}>
                      {c.realizado||0 < valAtual
                        ? `↑ Aumentando ${fmt(valAtual-(c.realizado||0))}`
                        : `↓ Reduzindo ${fmt((c.realizado||0)-valAtual)}`}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
          <button onClick={salvarEdicao} disabled={salvando}
            style={{width:"100%",marginTop:14,background:salvando?"#94a3b8":T.btn,border:"none",borderRadius:10,
              color:"#fff",fontSize:14,fontWeight:700,padding:"13px",cursor:salvando?"not-allowed":"pointer",
              boxShadow:"0 2px 8px rgba(37,99,235,0.3)",transition:"all 0.2s"}}>
            {salvando ? "💾 Salvando..." : "💾 Salvar todos os valores"}
          </button>
        </div>
      )}

      {/* ── SOMAR VENDAS ── */}
      {subTab === "somar" && (
        <div>
          <div style={{background:"#eff6ff",borderRadius:10,padding:"10px 14px",marginBottom:14,border:`1px solid ${T.cardBorder}`}}>
            <p style={{color:T.text,fontSize:12,fontWeight:600,margin:0}}>
              ➕ Digite o que cada um vendeu no dia. O sistema <strong>soma ao total atual</strong>.
            </p>
          </div>
          <div style={{display:"flex",gap:8,marginBottom:14}}>
            {[{key:"sab",lbl:"⚡ Sábado"},{key:"dom",lbl:"🌞 Domingo"},{key:"ambos",lbl:"📅 Ambos"}].map(d=>(
              <button key={d.key} onClick={()=>setDia(d.key)}
                style={{padding:"7px 14px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:12,
                  background:dia===d.key?T.btn:T.btnOff, color:dia===d.key?T.btnText:T.btnOffText}}>
                {d.lbl}
              </button>
            ))}
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            {colabs.filter(c=>c.nome).map(c => {
              const vS = novosSab[c.id]||0;
              const vD = novosDom[c.id]||0;
              const soma = vS+vD;
              return (
                <div key={c.id} style={{background:T.card,borderRadius:12,padding:"13px 16px",
                  border:`1px solid ${soma>0?T.btn:T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                  <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                    <div style={{width:34,height:34,borderRadius:99,background:soma>0?T.btn:"#94a3b8",
                      display:"flex",alignItems:"center",justifyContent:"center"}}>
                      <span style={{color:"#fff",fontSize:13,fontWeight:800}}>{c.nome[0]}</span>
                    </div>
                    <div style={{flex:1}}>
                      <p style={{color:T.text,fontSize:14,fontWeight:700,margin:"0 0 1px"}}>{c.nome}</p>
                      <p style={{color:T.muted,fontSize:11,margin:0}}>Total atual: {fmt(c.realizado||0)}</p>
                    </div>
                    {soma > 0 && (
                      <p style={{color:T.green,fontSize:12,fontWeight:700,margin:0}}>
                        → {fmt((c.realizado||0)+soma)}
                      </p>
                    )}
                  </div>
                  <div style={{display:"grid",gridTemplateColumns:dia==="ambos"?"1fr 1fr":"1fr",gap:8}}>
                    {(dia==="sab"||dia==="ambos") && (
                      <div>
                        <p style={{color:"#7c3aed",fontSize:10,fontWeight:700,margin:"0 0 3px",textTransform:"uppercase"}}>⚡ Sábado R$</p>
                        <input type="number" value={novosSab[c.id]||""} placeholder="0"
                          onChange={e=>setNovosSab(p=>({...p,[c.id]:parseFloat(e.target.value)||0}))}
                          style={{...inp,borderColor:vS>0?"#7c3aed":T.cardBorder}}/>
                      </div>
                    )}
                    {(dia==="dom"||dia==="ambos") && (
                      <div>
                        <p style={{color:"#0891b2",fontSize:10,fontWeight:700,margin:"0 0 3px",textTransform:"uppercase"}}>🌞 Domingo R$</p>
                        <input type="number" value={novosDom[c.id]||""} placeholder="0"
                          onChange={e=>setNovosDom(p=>({...p,[c.id]:parseFloat(e.target.value)||0}))}
                          style={{...inp,borderColor:vD>0?"#0891b2":T.cardBorder}}/>
                      </div>
                    )}
                  </div>
                  {soma > 0 && (
                    <p style={{color:T.green,fontSize:11,fontWeight:600,margin:"7px 0 0"}}>
                      ➕ {fmt(soma)} serão somados ao total
                    </p>
                  )}
                </div>
              );
            })}
          </div>
          <button onClick={salvarSoma} disabled={salvando}
            style={{width:"100%",marginTop:14,background:salvando?"#94a3b8":T.green,border:"none",borderRadius:10,
              color:"#fff",fontSize:14,fontWeight:700,padding:"13px",cursor:salvando?"not-allowed":"pointer",
              boxShadow:"0 2px 8px rgba(22,163,74,0.3)",transition:"all 0.2s"}}>
            {salvando ? "💾 Salvando..." : "💰 Somar ao ranking"}
          </button>
        </div>
      )}

      {/* ── DESAFIOS ── */}
      {subTab === "desafios" && (
        <div>
          <div style={{background:"#eff6ff",borderRadius:10,padding:"10px 14px",marginBottom:14,border:`1px solid ${T.cardBorder}`}}>
            <p style={{color:T.text,fontSize:12,fontWeight:600,margin:0}}>
              Digite a quantidade acumulada de cada item. Os pontos são calculados automaticamente.
            </p>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))",gap:10}}>
            {colabs.filter(c=>c.nome).map(c => (
              <div key={c.id} style={{background:T.card,borderRadius:12,padding:"13px",border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10,paddingBottom:8,borderBottom:`1px solid ${T.cardBorder}`}}>
                  <div style={{width:30,height:30,borderRadius:99,background:T.btn,display:"flex",alignItems:"center",justifyContent:"center"}}>
                    <span style={{color:"#fff",fontSize:12,fontWeight:800}}>{c.nome[0]}</span>
                  </div>
                  <span style={{color:T.text,fontSize:13,fontWeight:700,flex:1}}>{c.nome}</span>
                  <span style={{background:"#7c3aed",color:"#fff",fontSize:10,fontWeight:700,padding:"2px 7px",borderRadius:99}}>
                    {calcPontos(c)} pts
                  </span>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:7}}>
                  {[
                    {field:"prato",      label:"🥩 Mignon",    color:"#f59e0b", pts:4},
                    {field:"costelinha", label:"🍖 Costelinha", color:"#dc2626", pts:3},
                    {field:"drink",      label:"🥤 Refrig. Natural", color:"#0ea5e9", pts:2},
                    {field:"suco",       label:"🥤 Suco",       color:"#06b6d4", pts:1},
                    {field:"sobremesa",  label:"🍮 Sobremesa",  color:"#a855f7", pts:1},
                    {field:"avaliacao",  label:"⭐ Aval. 5★",  color:T.green,   pts:0},
                  ].map(({field,label,color,pts}) => (
                    <div key={field}>
                      <p style={{color,fontSize:9,margin:"0 0 2px",fontWeight:700,textTransform:"uppercase"}}>
                        {label}{pts>0?` (${pts}pt)`:""}</p>
                      <input type="number" value={c[field]||""} placeholder="0"
                        onChange={e=>onAtualizarDesafio(c.id,field,e.target.value)}
                        style={{width:"100%",background:T.pageBg,border:`1.5px solid ${c[field]?color:T.cardBorder}`,
                          borderRadius:7,color:T.text,fontSize:13,padding:"6px 9px",outline:"none",boxSizing:"border-box"}}/>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── EQUIPE ── */}
      {subTab === "equipe" && (
        <div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:10}}>
            {colabs.map(c => (
              <div key={c.id} style={{background:T.card,borderRadius:12,padding:"13px",border:`1px solid ${T.cardBorder}`,position:"relative",boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                <button onClick={()=>removeColab(c.id)}
                  style={{position:"absolute",top:8,right:10,background:"transparent",border:"none",color:T.muted,cursor:"pointer",fontSize:16}}>×</button>
                <input value={c.nome} onChange={e=>updateNome(c.id,e.target.value)} placeholder="Nome do colaborador"
                  style={{width:"100%",background:"transparent",border:"none",borderBottom:`1px solid ${T.cardBorder}`,
                    color:T.text,fontSize:14,fontWeight:700,padding:"0 0 6px",outline:"none",boxSizing:"border-box"}}/>
                <p style={{color:T.muted,fontSize:11,margin:"8px 0 0"}}>Vendas: {fmt(c.realizado||0)}</p>
              </div>
            ))}
            <button onClick={addColab}
              style={{background:"transparent",border:`2px dashed ${T.cardBorder}`,borderRadius:12,
                color:T.muted,fontSize:26,cursor:"pointer",minHeight:100,display:"flex",alignItems:"center",justifyContent:"center"}}>+</button>
          </div>
        </div>
      )}
    </div>
  );
}


// ─── PROGRAMA EXCELENCIA E RECOMPENSA ────────────────────────────────────────
function AbaPremios({ colabs, fmt }) {
  const medal = ["1","2","3"];

  const elegiveisVendas    = colabs.filter(c => c.nome && c.realizado >= META_CAMPEAO).sort((a,b)=>b.realizado-a.realizado);
  const comPontos          = colabs.filter(c=>c.nome).map(c=>({...c,pontos:calcPontos(c)})).sort((a,b)=>b.pontos-a.pontos);
  const elegiveisConsultiva= comPontos.filter(c=>c.pontos>=META_PONTOS);
  const elegiveisAval      = colabs.filter(c=>c.nome&&(c.avaliacao||0)>=META_AVAL).sort((a,b)=>(b.avaliacao||0)-(a.avaliacao||0));

  const medalIcon = (i) => i===0?"🥇":i===1?"🥈":i===2?"🥉":`${i+1}º`;

  const Barra = ({atual,meta,cor}) => {
    const pct = Math.min(Math.round((atual/meta)*100),100);
    return (
      <div style={{marginTop:4}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}>
          <span style={{color:T.muted,fontSize:10}}>{atual} / {meta}</span>
          <span style={{color:pct>=100?T.green:cor,fontSize:10,fontWeight:700}}>{pct}%</span>
        </div>
        <div style={{background:T.barBg,borderRadius:99,height:6,overflow:"hidden"}}>
          <div style={{height:"100%",width:`${pct}%`,background:pct>=100?T.green:cor,borderRadius:99}}/>
        </div>
      </div>
    );
  };

  const HeaderCard = ({emoji,titulo,premio,minimo,cor,children}) => (
    <div style={{background:T.card,borderRadius:14,border:`2px solid ${cor}`,marginBottom:16,overflow:"hidden",boxShadow:"0 2px 8px rgba(37,99,235,0.08)"}}>
      <div style={{background:cor,padding:"13px 16px"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:22}}>{emoji}</span>
          <div>
            <p style={{color:"#fff",fontSize:14,fontWeight:800,margin:0}}>{titulo}</p>
            <p style={{color:"rgba(255,255,255,0.8)",fontSize:11,margin:0}}>Premio: {premio}</p>
          </div>
        </div>
        <div style={{background:"rgba(0,0,0,0.15)",borderRadius:7,padding:"4px 10px",marginTop:8,display:"inline-block"}}>
          <span style={{color:"#fff",fontSize:11,fontWeight:600}}>Minimo: {minimo}</span>
        </div>
      </div>
      <div style={{padding:"13px 14px"}}>{children}</div>
    </div>
  );

  return (
    <div>
      {/* Resumo */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(130px,1fr))",gap:10,marginBottom:16}}>
        {[
          {l:"Campea de Vendas",v:elegiveisVendas.length,cor:T.gold},
          {l:"Mestre Consultiva",v:elegiveisConsultiva.length,cor:"#7c3aed"},
          {l:"Nota 10",v:elegiveisAval.length,cor:T.green},
        ].map(s=>(
          <div key={s.l} style={{background:T.card,borderRadius:12,padding:"12px",border:`1px solid ${T.cardBorder}`,textAlign:"center"}}>
            <p style={{color:s.cor,fontSize:22,fontWeight:800,margin:"0 0 2px"}}>{s.v}</p>
            <p style={{color:T.muted,fontSize:10,margin:0}}>{s.l}</p>
            <p style={{color:T.muted,fontSize:9,margin:0}}>elegiveis</p>
          </div>
        ))}
      </div>

      {/* 1. Campea de Vendas */}
      <HeaderCard emoji="🏆" titulo="1. Campea de Vendas" premio="+50% gorjeta" minimo={fmt(META_CAMPEAO)} cor={T.gold}>
        {elegiveisVendas.length===0 ? (
          <div>
            <p style={{color:T.muted,fontSize:12,textAlign:"center",margin:"0 0 12px"}}>Nenhum atingiu o minimo ainda.</p>
            {[...colabs].filter(c=>c.nome).sort((a,b)=>b.realizado-a.realizado).slice(0,5).map((c,i)=>(
              <div key={c.id} style={{display:"flex",alignItems:"center",gap:8,padding:"7px 0",borderBottom:`1px solid ${T.cardBorder}`}}>
                <span style={{fontSize:i<3?16:12,minWidth:22,fontWeight:700}}>{medalIcon(i)}</span>
                <span style={{color:T.text,fontSize:12,fontWeight:700,flex:1}}>{c.nome}</span>
                <span style={{color:T.muted,fontSize:11}}>{fmt(c.realizado||0)}</span>
                <span style={{color:T.red,fontSize:10,fontWeight:600}}>falta {fmt(META_CAMPEAO-(c.realizado||0))}</span>
              </div>
            ))}
          </div>
        ):(
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {elegiveisVendas.map((c,i)=>(
              <div key={c.id} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",background:i===0?"#fef9c3":T.pageBg,borderRadius:9,border:`1px solid ${i===0?T.gold:T.cardBorder}`}}>
                <span style={{fontSize:i<3?18:13,minWidth:24,fontWeight:700}}>{medalIcon(i)}</span>
                <span style={{color:T.text,fontSize:13,fontWeight:700,flex:1}}>{c.nome}</span>
                <span style={{color:i===0?T.gold:T.muted,fontSize:13,fontWeight:700}}>{fmt(c.realizado)}</span>
                {i===0&&<span style={{background:T.gold,color:"#fff",fontSize:9,fontWeight:800,padding:"2px 7px",borderRadius:99}}>LIDER</span>}
              </div>
            ))}
          </div>
        )}
      </HeaderCard>

      {/* 2. Mestre Consultiva */}
      <HeaderCard emoji="🎯" titulo="2. Mestre da Venda Consultiva" premio="+50% gorjeta" minimo={`${META_PONTOS} pontos`} cor="#7c3aed">
        <div style={{background:"#f5f3ff",borderRadius:9,padding:"8px 12px",marginBottom:12,border:"1px solid #ddd6fe"}}>
          <p style={{color:"#4c1d95",fontSize:10,fontWeight:700,margin:"0 0 6px",textTransform:"uppercase"}}>Sistema de pontos</p>
          <div style={{display:"flex",flexDirection:"column",gap:3}}>
            {[["🥩 Mignon Gratinado","4pts","#f59e0b"],["🍖 Costelinha de Pacu","3pts","#dc2626"],["🥤 Refrigerante Natural","2pts","#0ea5e9"],["🧃 Suco Natural","1pt","#06b6d4"],["🍮 Sobremesa","1pt","#a855f7"]].map(([l,p,c])=>(
              <div key={l} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{color:"#4c1d95",fontSize:11}}>{l}</span>
                <span style={{background:c,color:"#fff",fontSize:10,fontWeight:700,padding:"1px 7px",borderRadius:99}}>{p}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {comPontos.map((c,i)=>(
            <div key={c.id} style={{background:T.card,borderRadius:10,padding:"10px 13px",border:c.pontos>=META_PONTOS?`2px solid #7c3aed`:`1px solid ${T.cardBorder}`}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                <span style={{fontSize:i<3?17:12,minWidth:22,fontWeight:700,color:i>=3?T.muted:undefined}}>{medalIcon(i)}</span>
                <span style={{color:T.text,fontSize:13,fontWeight:700,flex:1}}>{c.nome}</span>
                <span style={{color:c.pontos>=META_PONTOS?"#7c3aed":T.muted,fontSize:14,fontWeight:800}}>{c.pontos} pts</span>
                {c.pontos>=META_PONTOS&&<span style={{background:"#7c3aed",color:"#fff",fontSize:9,fontWeight:800,padding:"2px 7px",borderRadius:99}}>ELEGIVEL</span>}
              </div>
              <Barra atual={c.pontos} meta={META_PONTOS} cor="#7c3aed"/>
              <div style={{display:"flex",gap:8,marginTop:5,flexWrap:"wrap"}}>
                <span style={{color:"#f59e0b",fontSize:10}}>🥩 {c.prato||0}x4</span>
                <span style={{color:"#dc2626",fontSize:10}}>🍖 {c.costelinha||0}x3</span>
                <span style={{color:"#0ea5e9",fontSize:10}}>🥤 {c.drink||0}x2</span>
                <span style={{color:"#06b6d4",fontSize:10}}>🧃 {c.suco||0}x1</span>
                <span style={{color:"#a855f7",fontSize:10}}>🍮 {c.sobremesa||0}x1</span>
              </div>
            </div>
          ))}
        </div>
      </HeaderCard>

      {/* 3. Nota 10 */}
      <HeaderCard emoji="⭐" titulo="3. Atendimento Nota 10" premio="R$ 150 ou folga" minimo={`${META_AVAL} avaliacoes 5 estrelas`} cor={T.green}>
        <div style={{display:"flex",flexDirection:"column",gap:7}}>
          {[...colabs].filter(c=>c.nome).sort((a,b)=>(b.avaliacao||0)-(a.avaliacao||0)).map((c,i)=>{
            const aval=c.avaliacao||0;
            const ok=aval>=META_AVAL;
            return(
              <div key={c.id} style={{background:T.card,borderRadius:10,padding:"10px 13px",border:ok?`2px solid ${T.green}`:`1px solid ${T.cardBorder}`}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                  <span style={{fontSize:i<3?17:12,minWidth:22,fontWeight:700,color:i>=3?T.muted:undefined}}>{medalIcon(i)}</span>
                  <span style={{color:T.text,fontSize:13,fontWeight:700,flex:1}}>{c.nome}</span>
                  <span style={{color:ok?T.green:T.muted,fontSize:14,fontWeight:800}}>★ {aval}</span>
                  {ok&&<span style={{background:T.green,color:"#fff",fontSize:9,fontWeight:800,padding:"2px 7px",borderRadius:99}}>ELEGIVEL</span>}
                </div>
                <Barra atual={aval} meta={META_AVAL} cor={T.green}/>
                {!ok&&aval>0&&<p style={{color:T.muted,fontSize:10,margin:"4px 0 0"}}>Faltam {META_AVAL-aval} avaliacoes</p>}
              </div>
            );
          })}
        </div>
      </HeaderCard>
    </div>
  );
}


// ─── LOGO SARDÃO ─────────────────────────────────────────────────────────────
function LogoSardao({ size = 120, corLogo = "#ffffff" }) {
  const scale = size / 120;
  return (
    <svg width={220*scale} height={100*scale} viewBox="0 0 220 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="10" y1="8" x2="210" y2="8" stroke={corLogo} strokeWidth="0.8" opacity="0.4"/>
      <text x="110" y="30" textAnchor="middle" fontSize="13" fontWeight="500"
        fill={corLogo} fontFamily="Georgia,'Times New Roman',serif" letterSpacing="6" opacity="0.85">
        A QUINTA DO
      </text>
      <text x="110" y="68" textAnchor="middle" fontSize="40" fontWeight="800"
        fill={corLogo} fontFamily="Georgia,'Times New Roman',serif" letterSpacing="4">
        SARDÃO
      </text>
      <line x1="20" y1="78" x2="200" y2="78" stroke={corLogo} strokeWidth="0.8" opacity="0.45"/>
      <text x="110" y="94" textAnchor="middle" fontSize="10" fontWeight="400"
        fill={corLogo} fontFamily="Georgia,'Times New Roman',serif" letterSpacing="4" opacity="0.7">
        DESDE 2008
      </text>
    </svg>
  );
}


// ─── TELA DE BOAS-VINDAS ─────────────────────────────────────────────────────
function BoasVindas({ cfg, colabs, onEntrar, fmt }) {
  const totalR      = colabs.reduce((s,c) => s+(c.realizado||0), 0);
  const bateram     = colabs.filter(c => c.nome && c.realizado >= META_CAMPEAO).length;
  const elegConsult = colabs.filter(c => calcPontos(c) >= META_PONTOS).length;
  const prazo       = cfg?.prazo ? new Date(cfg.prazo) : null;
  const hoje        = new Date();
  const diasRest    = prazo ? Math.max(0, Math.ceil((prazo - hoje)/86400000)) : null;

  return (
    <div>
      <div style={{background:`linear-gradient(135deg,${T.primaryDark} 0%,#1d4ed8 100%)`,borderRadius:18,padding:"26px 20px",marginBottom:16,textAlign:"center"}}>
        <div style={{marginBottom:12}}>
          <LogoSardao size={140} corLogo="#ffffff"/>
        </div>
        <p style={{fontSize:9,textTransform:"uppercase",letterSpacing:3,color:"rgba(255,255,255,0.75)",margin:"0 0 8px"}}>Programa Excelencia e Recompensa</p>
        <h1 style={{fontSize:26,fontWeight:800,margin:"0 0 6px",color:"#ffffff",letterSpacing:-0.5,textShadow:"0 2px 8px rgba(0,0,0,0.3)"}}>{cfg?.nome || "Campanha em andamento"}</h1>
        {cfg?.nomePrato && (
          <div style={{background:"rgba(255,255,255,0.18)",borderRadius:8,padding:"5px 14px",display:"inline-block",marginBottom:18}}>
            <p style={{color:"#fff",fontSize:13,fontWeight:600,margin:0}}>Prato do mes: <strong>{cfg.nomePrato}</strong></p>
          </div>
        )}
        {!cfg?.nomePrato && <div style={{marginBottom:18}}/>}
        {diasRest !== null && (
          <div style={{background:"rgba(0,0,0,0.25)",borderRadius:12,padding:"12px 24px",display:"inline-block",marginBottom:18,border:"1px solid rgba(255,255,255,0.2)"}}>
            {diasRest > 0
              ? <>
                  <p style={{color:"rgba(255,255,255,0.8)",fontSize:10,margin:"0 0 2px",textTransform:"uppercase",letterSpacing:1}}>Dias restantes</p>
                  <p style={{fontSize:38,fontWeight:800,margin:0,color:"#fff",textShadow:"0 2px 8px rgba(0,0,0,0.3)"}}>{diasRest}</p>
                </>
              : <p style={{fontSize:14,fontWeight:700,margin:0,color:"#fff"}}>Campanha encerrada</p>}
          </div>
        )}
        <div style={{display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap"}}>
          {[
            {l:"Total equipe",    v:fmt(totalR)},
            {l:"Bateram R$ 50k",  v:String(bateram)+" garcons"},
            {l:"Eleg. Consultiva",v:String(elegConsult)},
          ].map(s=>(
            <div key={s.l} style={{background:"rgba(0,0,0,0.2)",borderRadius:10,padding:"9px 14px",textAlign:"center",minWidth:90,border:"1px solid rgba(255,255,255,0.15)"}}>
              <p style={{fontSize:14,fontWeight:800,margin:"0 0 2px",color:"#fff"}}>{s.v}</p>
              <p style={{fontSize:9,color:"rgba(255,255,255,0.7)",margin:0,textTransform:"uppercase"}}>{s.l}</p>
            </div>
          ))}
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:12,marginBottom:14}}>
        <div style={{background:T.card,borderRadius:14,padding:"14px",border:`2px solid ${T.gold}`}}>
          <p style={{color:T.text,fontSize:13,fontWeight:800,margin:"0 0 4px"}}>Campea de Vendas</p>
          <p style={{color:T.gold,fontSize:11,fontWeight:700,margin:"0 0 8px"}}>+50% sobre a gorjeta</p>
          <div style={{background:"#fef9c3",borderRadius:8,padding:"7px 10px",marginBottom:7}}>
            <p style={{color:"#92400e",fontSize:12,fontWeight:700,margin:0}}>Minimo: {fmt(META_CAMPEAO)}</p>
          </div>
          <p style={{color:T.muted,fontSize:11,margin:0}}>Maior faturamento individual. Desempate: maior ticket medio.</p>
        </div>

        <div style={{background:T.card,borderRadius:14,padding:"14px",border:"2px solid #7c3aed"}}>
          <p style={{color:T.text,fontSize:13,fontWeight:800,margin:"0 0 4px"}}>Mestre da Venda Consultiva</p>
          <p style={{color:"#7c3aed",fontSize:11,fontWeight:700,margin:"0 0 8px"}}>+50% sobre a gorjeta</p>
          <div style={{background:"#ede9fe",borderRadius:8,padding:"7px 10px",marginBottom:8}}>
            <p style={{color:"#4c1d95",fontSize:12,fontWeight:700,margin:0}}>Minimo: {META_PONTOS} pontos</p>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:4}}>
            {[["Mignon Gratinado","4pts"],["Costelinha de Pacu","3pts"],["Refrigerante Natural","2pts"],["Suco Natural","1pt"],["Sobremesa","1pt"]].map(([l,p])=>(
              <div key={l} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{color:T.muted,fontSize:11}}>{l}</span>
                <span style={{background:"#7c3aed",color:"#fff",fontSize:10,fontWeight:700,padding:"1px 7px",borderRadius:99}}>{p}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{background:T.card,borderRadius:14,padding:"14px",border:`2px solid ${T.green}`}}>
          <p style={{color:T.text,fontSize:13,fontWeight:800,margin:"0 0 4px"}}>Atendimento Nota 10</p>
          <p style={{color:T.green,fontSize:11,fontWeight:700,margin:"0 0 8px"}}>R$ 150 ou folga no mes</p>
          <div style={{background:T.greenBg,borderRadius:8,padding:"7px 10px",marginBottom:8}}>
            <p style={{color:T.greenText,fontSize:12,fontWeight:700,margin:0}}>Minimo: {META_AVAL} avaliacoes 5 estrelas</p>
          </div>
          {["Nome citado no elogio","Sem reclamacao grave","Sem advertencia no mes"].map(r=>(
            <p key={r} style={{color:T.muted,fontSize:11,margin:"2px 0"}}>v {r}</p>
          ))}
        </div>
      </div>

      <div style={{background:T.card,borderRadius:12,padding:"14px",marginBottom:14,border:`1px solid ${T.cardBorder}`}}>
        <p style={{color:T.text,fontSize:12,fontWeight:700,margin:"0 0 10px"}}>Para participar de qualquer premiacao:</p>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:5}}>
          {["Sem faltas injustificadas","Sem advertencia disciplinar","Cumprir horarios","Uniforme completo","Boa postura e apresentacao","Seguir processos da empresa"].map(c=>(
            <div key={c} style={{display:"flex",alignItems:"center",gap:6,padding:"5px 9px",background:T.pageBg,borderRadius:7}}>
              <span style={{color:T.green,fontSize:11,fontWeight:700}}>v</span>
              <span style={{color:T.text,fontSize:11}}>{c}</span>
            </div>
          ))}
        </div>
      </div>

      <button onClick={onEntrar}
        style={{width:"100%",background:T.btn,border:"none",borderRadius:12,color:"#fff",fontSize:15,fontWeight:800,padding:"14px",cursor:"pointer",boxShadow:"0 4px 16px rgba(37,99,235,0.3)"}}>
        Ver ranking e metas
      </button>
    </div>
  );
}


// ─── LOGIN ────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState(false);
  const tentar = () => { if (senha === SENHA_ADMIN) onLogin(); else { setErro(true); setSenha(""); } };
  return (
    <div style={{minHeight:"100vh",background:T.pageBg,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Segoe UI',system-ui,sans-serif"}}>
      <div style={{background:T.card,borderRadius:18,padding:36,width:320,textAlign:"center",boxShadow:"0 4px 24px rgba(37,99,235,0.12)",border:`1px solid ${T.cardBorder}`}}>
        <p style={{fontSize:36,margin:"0 0 8px"}}>🔐</p>
        <h2 style={{color:T.text,fontSize:18,fontWeight:700,margin:"0 0 6px"}}>Área Administrativa</h2>
        <p style={{color:T.muted,fontSize:12,margin:"0 0 24px"}}>Quinta do Sardão</p>
        <input type="password" value={senha} onChange={e=>{setSenha(e.target.value);setErro(false);}} onKeyDown={e=>e.key==="Enter"&&tentar()} placeholder="Digite a senha"
          style={{width:"100%",background:T.pageBg,border:erro?`1px solid ${T.red}`:`1px solid ${T.cardBorder}`,borderRadius:9,color:T.text,fontSize:14,padding:"10px 14px",outline:"none",boxSizing:"border-box",marginBottom:8}}/>
        {erro && <p style={{color:T.red,fontSize:12,margin:"0 0 10px"}}>Senha incorreta</p>}
        <button onClick={tentar} style={{width:"100%",background:T.btn,border:"none",borderRadius:9,color:"#fff",fontSize:14,fontWeight:700,padding:"10px",cursor:"pointer",marginTop:4}}>Entrar</button>
      </div>
    </div>
  );
}

// ─── PAINEL PRINCIPAL ─────────────────────────────────────────────────────────
function Painel({ isAdmin }) {
  const [data, setData] = useState(defaultData);
  const [mesAtivo, setMesAtivo] = useState("ago26");
  const [tab, setTab] = useState("boasvindas");
  const [status, setStatus] = useState("");
  const [carregando, setCarregando] = useState(true);

  const carregarDados = useCallback(async () => {
    try {
      const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}/latest`, {headers:{"X-Master-Key":API_KEY}});
      if (r.ok) {
        const json = await r.json();
        if (json.record?.meses) setData(json.record);
      }
    } catch(e) {}
    setCarregando(false);
  }, []);

  useEffect(() => { carregarDados(); }, [carregarDados]);

  const salvar = async (novoData) => {
    setStatus("salvando");
    try {
      const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}`, {
        method:"PUT",
        headers:{"Content-Type":"application/json","X-Master-Key":API_KEY},
        body:JSON.stringify(novoData)
      });
      setData(novoData);
      setStatus(r.ok?"salvo":"erro");
      if (r.ok) setTimeout(()=>setStatus(""),2500);
    } catch(e) { setStatus("erro"); }
  };

  const cfgAtiva = data.mesesConfig.find(m => m.id === mesAtivo);
  const colabsAtivos = data.meses[mesAtivo]?.colabs || [];

  const updateNum = (id, field, val) => {
    if (!isAdmin) return;
    // Aceita inteiros e decimais (ex: 11125,50 ou 11125.50)
    const limpo = String(val).replace(",", ".").replace(/[^0-9.]/g, "");
    const num = parseFloat(limpo) || 0;
    const novoMes = { ...data.meses[mesAtivo], colabs: colabsAtivos.map(c => c.id===id?{...c,[field]:num}:c) };
    salvar({ ...data, meses:{ ...data.meses, [mesAtivo]:novoMes } });
  };

  // Salva direto sem chamar updateNum (usado pela AbaLancamento editar)
  const salvarDireto = (id, field, val) => {
    if (!isAdmin) return;
    const limpo = String(val).replace(",", ".").replace(/[^0-9.]/g, "");
    const num = parseFloat(limpo) || 0;
    const novoMes = { ...data.meses[mesAtivo], colabs: colabsAtivos.map(c => c.id===id?{...c,[field]:num}:c) };
    salvar({ ...data, meses:{ ...data.meses, [mesAtivo]:novoMes } });
  };

  const updateNome = (id, val) => {
    if (!isAdmin) return;
    const novoMes = { ...data.meses[mesAtivo], colabs: colabsAtivos.map(c => c.id===id?{...c,nome:val}:c) };
    salvar({ ...data, meses:{ ...data.meses, [mesAtivo]:novoMes } });
  };

  const addColab = () => {
    if (!isAdmin) return;
    const maxId = Math.max(...colabsAtivos.map(c=>c.id),0)+1;
    const novoMes = { ...data.meses[mesAtivo], colabs:[...colabsAtivos,{id:maxId,nome:"",realizado:0,prato:0,sobremesa:0,suco:0}] };
    salvar({ ...data, meses:{ ...data.meses, [mesAtivo]:novoMes } });
  };

  const removeColab = (id) => {
    if (!isAdmin) return;
    const novoMes = { ...data.meses[mesAtivo], colabs:colabsAtivos.filter(c=>c.id!==id) };
    salvar({ ...data, meses:{ ...data.meses, [mesAtivo]:novoMes } });
  };

  const fecharMes = () => {
    if (!isAdmin) return;
    if (!window.confirm(`Fechar ${cfgAtiva?.nome}? Os dados serão arquivados.`)) return;
    const novoMes = { ...data.meses[mesAtivo], fechado:true };
    salvar({ ...data, meses:{ ...data.meses, [mesAtivo]:novoMes } });
  };

  const sorted = [...colabsAtivos].filter(c=>c.nome).sort((a,b)=>b.realizado-a.realizado);
  const totalR = colabsAtivos.reduce((s,c)=>s+(c.realizado||0),0);
  const totalPct = cfgAtiva ? Math.round((totalR/(cfgAtiva.metaR*colabsAtivos.filter(c=>c.nome).length))*100)||0 : 0;

  const inp = {width:"100%",background:T.pageBg,border:`1px solid ${T.cardBorder}`,borderRadius:7,color:T.text,fontSize:13,padding:"6px 9px",outline:"none",boxSizing:"border-box"};
  const tabBtn = (key,lbl) => (
    <button onClick={()=>setTab(key)} style={{padding:"7px 13px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:12,background:tab===key?T.btn:T.btnOff,color:tab===key?T.btnText:T.btnOffText,whiteSpace:"nowrap"}}>{lbl}</button>
  );

  if (carregando) return (
    <div style={{minHeight:"100vh",background:T.pageBg,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Segoe UI',system-ui,sans-serif"}}>
      <p style={{color:T.muted}}>Carregando dados...</p>
    </div>
  );

  return (
    <div style={{minHeight:"100vh",background:T.pageBg,fontFamily:"'Segoe UI',system-ui,sans-serif"}}>
      {/* HEADER */}
      <div style={{background:T.header,padding:"18px 20px 24px"}}>
        <div style={{maxWidth:1020,margin:"0 auto"}}>
          <p style={{color:T.headerSub,fontSize:10,textTransform:"uppercase",letterSpacing:2,margin:"0 0 2px"}}>Quinta do Sardão</p>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:10,marginBottom:14}}>
            <div>
              <h1 style={{color:"#fff",fontSize:20,fontWeight:800,margin:"0 0 4px"}}>🏆 Painel de Metas 2026</h1>
              {isAdmin
                ? <span style={{background:"rgba(255,255,255,0.15)",color:"#bfdbfe",fontSize:10,fontWeight:700,padding:"2px 10px",borderRadius:99}}>🔐 MODO ADMIN</span>
                : <span style={{background:"rgba(255,255,255,0.10)",color:"rgba(255,255,255,0.6)",fontSize:10,fontWeight:700,padding:"2px 10px",borderRadius:99}}>👁 SOMENTE VISUALIZAÇÃO</span>
              }
            </div>
            {cfgAtiva && (
              <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4}}>
                <p style={{color:T.headerSub,fontSize:10,margin:0,textTransform:"uppercase"}}>⏳ Prazo: {new Date(cfgAtiva.prazo).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"})}</p>
                <Countdown prazo={cfgAtiva.prazo} />
              </div>
            )}
          </div>

          {/* Seletor de mês */}
          <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:14}}>
            {data.mesesConfig.map(m => (
              <button key={m.id} onClick={()=>{setMesAtivo(m.id);setTab("ranking");}} style={{padding:"5px 12px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:11,background:mesAtivo===m.id?"rgba(255,255,255,0.25)":"rgba(255,255,255,0.08)",color:mesAtivo===m.id?"#fff":"rgba(255,255,255,0.6)"}}>
                {m.nome.split(" ")[0]} {data.meses[m.id]?.fechado?"✔":""}
              </button>
            ))}
          </div>

          {/* Totalizador */}
          <div style={{display:"flex",gap:16,flexWrap:"wrap",alignItems:"center"}}>
            <div>
              <p style={{color:T.headerSub,fontSize:9,margin:"0 0 2px",textTransform:"uppercase"}}>Meta p/ pessoa</p>
              <p style={{color:"#fff",fontSize:15,fontWeight:700,margin:0}}>{cfgAtiva?fmt(cfgAtiva.metaR):"—"}</p>
            </div>
            <div>
              <p style={{color:T.headerSub,fontSize:9,margin:"0 0 2px",textTransform:"uppercase"}}>Realizado total</p>
              <p style={{color:"#fff",fontSize:15,fontWeight:700,margin:0}}>{fmt(totalR)}</p>
            </div>
            <div style={{flex:1,minWidth:100}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                <span style={{color:T.headerSub,fontSize:9,textTransform:"uppercase"}}>Progresso geral</span>
                <span style={{color:"#fff",fontSize:12,fontWeight:700}}>{totalPct}%</span>
              </div>
              <div style={{background:"rgba(255,255,255,0.2)",borderRadius:99,height:7,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${Math.min(totalPct,100)}%`,background:totalPct>=100?"#4ade80":totalPct>=80?"#fbbf24":"#93c5fd",borderRadius:99}}/>
              </div>
            </div>
            <div style={{display:"flex",gap:7}}>
              {[
                {label:"Bateram", count:colabsAtivos.filter(c=>c.nome&&cfgAtiva&&c.realizado>=cfgAtiva.metaR).length, color:"#4ade80"},
                {label:"Quase",   count:colabsAtivos.filter(c=>c.nome&&cfgAtiva&&c.realizado>=cfgAtiva.metaR*0.8&&c.realizado<cfgAtiva.metaR).length, color:"#fbbf24"},
                {label:"Não bat.",count:colabsAtivos.filter(c=>c.nome&&cfgAtiva&&c.realizado<cfgAtiva.metaR*0.8).length, color:"#f87171"},
              ].map(s=>(
                <div key={s.label} style={{background:"rgba(0,0,0,0.2)",borderRadius:8,padding:"5px 9px",textAlign:"center"}}>
                  <p style={{color:s.color,fontSize:14,fontWeight:700,margin:0}}>{s.count}</p>
                  <p style={{color:"rgba(255,255,255,0.5)",fontSize:8,margin:0}}>{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CONTEÚDO */}
      <div style={{maxWidth:1020,margin:"-10px auto 0",padding:"0 14px 28px"}}>
        <div style={{background:T.card,borderRadius:12,padding:"10px 14px",display:"flex",gap:7,flexWrap:"wrap",marginBottom:14,boxShadow:"0 2px 8px rgba(37,99,235,0.08)",border:`1px solid ${T.cardBorder}`}}>
          {tabBtn("boasvindas","🏠 Início")}
          {tabBtn("ranking","🏅 Ranking")}
          {tabBtn("prato",  "⭐ Prato do Mês")}
          {tabBtn("sobre",  "🍮 Sobremesas")}
          {tabBtn("suco",   "🍹 Sucos/Drinks")}
          {tabBtn("setores","🗺️ Setores")}
          {tabBtn("premios","🏆 Premiação")}
          
          {isAdmin && tabBtn("relatorio","📊 Relatórios")}
          {isAdmin && tabBtn("editar","✏️ Editar")}
          {isAdmin && tabBtn("config","⚙️ Config Meses")}
          {isAdmin && tabBtn("sorteio","🎡 Roleta")}
          {isAdmin && tabBtn("escalaadmin","📋 Editar Escala")}
        </div>

        {status==="salvando" && <div style={{background:"#dbeafe",color:T.text,fontSize:12,fontWeight:600,borderRadius:8,padding:"7px 14px",marginBottom:10,textAlign:"center"}}>💾 Salvando...</div>}
        {status==="salvo"    && <div style={{background:T.greenBg,color:T.greenText,fontSize:12,fontWeight:600,borderRadius:8,padding:"7px 14px",marginBottom:10,textAlign:"center"}}>✅ Dados salvos!</div>}
        {status==="erro"     && <div style={{background:T.redBg,color:T.redText,fontSize:12,fontWeight:600,borderRadius:8,padding:"7px 14px",marginBottom:10,textAlign:"center"}}>❌ Erro ao salvar.</div>}

        {data.meses[mesAtivo]?.fechado && tab !== "relatorio" && (
          <div style={{background:T.greenBg,color:T.greenText,fontSize:12,fontWeight:600,borderRadius:8,padding:"8px 14px",marginBottom:12,textAlign:"center"}}>
            ✔ Este mês foi fechado e arquivado. Veja os dados no Relatório.
          </div>
        )}

        {/* BOAS-VINDAS */}
        {tab==="boasvindas" && (
          <BoasVindas
            cfg={cfgAtiva}
            colabs={colabsAtivos}
            mesAtivo={mesAtivo}
            onEntrar={() => setTab("ranking")}
            fmt={fmt}
          />
        )}

        {/* RANKING GERAL */}
        {tab==="ranking" && (
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {sorted.map((c,i) => {
              const pct = cfgAtiva ? Math.round((c.realizado/cfgAtiva.metaR)*100) : 0;
              const s = statusR(c.realizado, cfgAtiva?.metaR||1);
              const falta = cfgAtiva ? Math.max(0,cfgAtiva.metaR-c.realizado) : 0;
              return (
                <div key={c.id} style={{background:T.card,borderRadius:12,border:i===0?`2px solid ${T.gold}`:`1px solid ${T.cardBorder}`,padding:"13px 16px",boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
                  <div style={{display:"flex",alignItems:"center",gap:12,flexWrap:"wrap"}}>
                    <span style={{fontSize:i<3?22:14,minWidth:28,textAlign:"center",color:i>=3?T.muted:undefined,fontWeight:700}}>{i<3?medal[i]:`${i+1}º`}</span>
                    <span style={{color:T.text,fontSize:15,fontWeight:700,minWidth:90}}>{c.nome}</span>
                    <span style={{color:T.muted,fontSize:13,minWidth:100}}>{fmt(c.realizado)}</span>
                    <div style={{flex:1,minWidth:80}}>
                      <div style={{background:T.barBg,borderRadius:99,height:7,overflow:"hidden"}}>
                        <div style={{height:"100%",width:`${Math.min(pct,100)}%`,background:s.bar,borderRadius:99}}/>
                      </div>
                    </div>
                    <span style={{color:s.bar,fontSize:13,fontWeight:700,minWidth:40,textAlign:"right"}}>{pct}%</span>
                    <span style={{background:s.badge.bg,color:s.badge.text,fontSize:10,fontWeight:600,padding:"3px 8px",borderRadius:99}}>{s.label}</span>
                  </div>
                  {falta>0 && <p style={{color:T.muted,fontSize:10,margin:"6px 0 0 40px"}}>Falta {fmt(falta)} para bater a meta</p>}
                </div>
              );
            })}
          </div>
        )}

        {tab==="prato" && cfgAtiva && <RankingTab colabs={colabsAtivos} field="prato"     label={cfgAtiva.nomePrato||"Prato do Mês"} color="#f59e0b" emoji="⭐" metaInd={cfgAtiva.metaPrato} />}
        {tab==="sobre" && cfgAtiva && <RankingTab colabs={colabsAtivos} field="sobremesa" label="Sobremesas"                         color="#a855f7" emoji="🍮" metaInd={cfgAtiva.metaSobre}  />}
        {tab==="suco"  && cfgAtiva && <RankingTab colabs={colabsAtivos} field="suco"      label="Sucos / Drinks s/ álcool"           color="#0ea5e9" emoji="🍹" metaInd={cfgAtiva.metaSuco}   />}

        {tab==="relatorio" && <Relatorios data={data} />}

        {tab==="premios" && <AbaPremios colabs={colabsAtivos} fmt={fmt} />}

        {tab==="setores" && <AbaSetores isAdmin={isAdmin} escalaData={data.escala} fatSetorData={data.fatSetor} colabsAtivos={colabsAtivos} onSalvarEscala={(nova) => salvar({...data, escala: nova})} onSalvarFat={(nova) => salvar({...data, fatSetor: nova})} />}

        {tab==="config" && isAdmin && <ConfigMes data={data} onSave={salvar} />}

        {tab==="sorteio" && isAdmin && <AbaRoleta escalaData={data.escala} onSalvarEscala={(nova) => salvar({...data, escala: nova})} />}
        {tab==="escalaadmin" && isAdmin && <AbaEscalaAdmin escalaData={data.escala} onSalvar={(nova) => salvar({...data, escala: nova})} />}

        {tab==="editar" && isAdmin && (
          <AbaLancamento
            colabs={colabsAtivos}
            cfgAtiva={cfgAtiva}
            fechado={data.meses[mesAtivo]?.fechado}
            onFecharMes={fecharMes}
            onSalvarDireto={(id, field, valor) => salvarDireto(id, field, valor)}
            onSalvarBatch={(mapa) => {
              const novosMes = {
                ...data.meses[mesAtivo],
                colabs: colabsAtivos.map(c => mapa[c.id] !== undefined ? {...c, realizado: mapa[c.id]} : c)
              };
              salvar({ ...data, meses:{ ...data.meses, [mesAtivo]:novosMes } });
            }}
            onSomar={(id, valorSab, valorDom) => {
              const c = colabsAtivos.find(x => x.id === id);
              if (!c) return;
              const novoTotal = (c.realizado || 0) + valorSab + valorDom;
              updateNum(id, "realizado", novoTotal.toString());
            }}
            onAtualizarDesafio={(id, field, valor) => updateNum(id, field, valor)}
            addColab={addColab}
            removeColab={removeColab}
            updateNome={updateNome}
            fmt={fmt}
          />
        )}
      </div>
    </div>
  );
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
// ─── ROLETA SVG ───────────────────────────────────────────────────────────────
function RoletaSVG({ setores, angulo }) {
  const n=setores.length, fatia=(2*Math.PI)/n, r=115, cx=130, cy=130;
  const items=setores.map((s,i)=>{
    const ang=(angulo*Math.PI/180)-Math.PI/2;
    const ini=i*fatia+ang, fim=ini+fatia;
    const x1=cx+r*Math.cos(ini),y1=cy+r*Math.sin(ini);
    const x2=cx+r*Math.cos(fim),y2=cy+r*Math.sin(fim);
    const mid=ini+fatia/2;
    const tx=cx+(r*0.65)*Math.cos(mid),ty=cy+(r*0.65)*Math.sin(mid);
    return {s,x1,y1,x2,y2,tx,ty,large:fatia>Math.PI?1:0};
  });
  return (
    <svg width={260} height={260} viewBox="0 0 260 260" style={{filter:"drop-shadow(0 4px 16px rgba(37,99,235,0.25))"}}>
      <polygon points="130,4 122,22 138,22" fill={T.gold}/>
      {items.map(({s,x1,y1,x2,y2,tx,ty,large},i)=>(
        <g key={i}>
          <path d={`M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${large},1 ${x2},${y2} Z`} fill={s.cor} stroke="#fff" strokeWidth={2}/>
          <text x={tx} y={ty} textAnchor="middle" dominantBaseline="middle" fontSize={9} fontWeight="bold" fill="#fff">{s.nome.split(" ")[0]}</text>
        </g>
      ))}
      <circle cx={cx} cy={cy} r={18} fill="#fff" stroke="#e0e7ff" strokeWidth={3}/>
      <circle cx={cx} cy={cy} r={10} fill={T.btn}/>
    </svg>
  );
}

// ─── ABA ROLETA ───────────────────────────────────────────────────────────────
const SORTEIO_CONFIG = {
  sab: {
    fixos: [
      { setor:"varanda",  nome:"Varanda",      cor:"#ca8a04", garcons:["Luís"]    },
      { setor:"boqueta",  nome:"Boqueta",       cor:"#ea580c", garcons:["Leandro"] },
    ],
    participantes: ["LG","Sarah","Patrícia","Zé"],
    vagas: [
      { setor:"salao",   nome:"Salão",         cor:"#7c3aed", vagas:2 },
      { setor:"quadric", nome:"Quadriculado",  cor:"#78716c", vagas:1 },
      { setor:"paquinho",nome:"Deck Paquinho", cor:"#2563eb", vagas:1 },
    ],
    fechados: ["deckbar"],
  },
  dom: {
    fixos: [
      { setor:"boqueta", nome:"Boqueta",       cor:"#ea580c", garcons:["Thaís"]   },
      { setor:"arvore",  nome:"Deck Árvore",   cor:"#16a34a", garcons:["Leandro"] },
      { setor:"varanda", nome:"Varanda",        cor:"#ca8a04", garcons:["Heitor"]  },
      { setor:"salao",   nome:"Salão",          cor:"#7c3aed", garcons:["Zé"],    parcial:true },
      { setor:"deckbar", nome:"Deck Bar",       cor:"#dc2626", garcons:["Luís"],  parcial:true },
    ],
    participantes: ["LG","Sarah","Patrícia"],
    vagas: [
      { setor:"salao",   nome:"Salão (+1)",    cor:"#7c3aed", vagas:1 },
      { setor:"deckbar", nome:"Deck Bar (+1)", cor:"#dc2626", vagas:1 },
      { setor:"quadric", nome:"Quadriculado",  cor:"#78716c", vagas:1 },
      { setor:"paquinho",nome:"Deck Paquinho", cor:"#2563eb", vagas:1 },
    ],
  },
};


// ─── ROLETA COM FIXOS CONFIGURADOS ───────────────────────────────────────────

const FIXOS_CONFIG = {
  sab: {
    fixos: [
      { setor:"varanda",  nome:"Varanda",      cor:"#ca8a04", garcons:["Luís"]           },
      { setor:"boqueta",  nome:"Boqueta",       cor:"#ea580c", garcons:["Leandro"]        },
      { setor:"pousada",  nome:"Pousada",       cor:"#0891b2", garcons:["Richard","Silvia"] },
    ],
    fechados: [{ setor:"deckbar", nome:"Deck Bar" }],
    sorteioGarcons: ["LG","Sarah","Patrícia","Zé","Sidmar"],
    sorteioSetores: [
      { setor:"salao",   nome:"Salão",         cor:"#7c3aed", vagas:2 },
      { setor:"quadric", nome:"Quadriculado",  cor:"#78716c", vagas:1 },
      { setor:"paquinho",nome:"Deck Paquinho", cor:"#2563eb", vagas:1 },
    ],
  },
  dom: {
    fixos: [
      { setor:"boqueta", nome:"Boqueta",       cor:"#ea580c", garcons:["Thaís"]            },
      { setor:"arvore",  nome:"Deck Árvore",   cor:"#16a34a", garcons:["Leandro"]          },
      { setor:"varanda", nome:"Varanda",        cor:"#ca8a04", garcons:["Sidmar"]           },
      { setor:"salao",   nome:"Salão",          cor:"#7c3aed", garcons:["Zé"],  parcial:true },
      { setor:"deckbar", nome:"Deck Bar",       cor:"#dc2626", garcons:["Luís"],parcial:true },
      { setor:"pousada", nome:"Pousada",        cor:"#0891b2", garcons:["Richard","Silvia"] },
    ],
    fechados: [],
    sorteioGarcons: ["LG","Sarah","Patrícia"],
    sorteioSetores: [
      { setor:"salao",   nome:"Salão (+1)",    cor:"#7c3aed", vagas:1 },
      { setor:"deckbar", nome:"Deck Bar (+1)", cor:"#dc2626", vagas:1 },
      { setor:"quadric", nome:"Quadriculado",  cor:"#78716c", vagas:1 },
      { setor:"paquinho",nome:"Deck Paquinho", cor:"#2563eb", vagas:1 },
    ],
  },
};

function AbaRoleta({ escalaData, onSalvarEscala }) {
  const [dia, setDia]           = useState("sab");
  const [tela, setTela]         = useState("fixos");
  const [vez, setVez]           = useState(0);
  const [girando, setGirando]   = useState(false);
  const [angulo, setAngulo]     = useState(0);
  const [resultados, setResultados] = useState([]);
  const [setorVez, setSetorVez] = useState(null);
  const [confirmado, setConfirmado] = useState(false);
  const animRef  = useRef(null);
  const startRef = useRef(null);

  const cfg     = FIXOS_CONFIG[dia];
  const garcons = cfg.sorteioGarcons;
  const atual   = garcons[vez];
  const setoresRoleta = SETORES.filter(s => cfg.sorteioSetores.some(ss => ss.setor === s.id));

  const reiniciar = (novoDia) => {
    cancelAnimationFrame(animRef.current);
    setTela("fixos"); setVez(0); setGirando(false); setAngulo(0);
    setResultados([]); setSetorVez(null); setConfirmado(false);
    if (novoDia) setDia(novoDia);
  };

  const girar = () => {
    if (girando) return;
    const usados = resultados.reduce((acc, r) => { acc[r.setor] = (acc[r.setor]||0)+1; return acc; }, {});
    const disponiveis = cfg.sorteioSetores.filter(s => (usados[s.setor]||0) < s.vagas);
    if (!disponiveis.length) return;
    const sorteado  = disponiveis[Math.floor(Math.random()*disponiveis.length)];
    const setorObj  = SETORES.find(s => s.id === sorteado.setor) || sorteado;
    const idx       = setoresRoleta.findIndex(s => s.id === sorteado.setor);
    const fatia     = 360 / setoresRoleta.length;
    const alvo      = 360*7 + (360 - (idx*fatia + fatia/2));
    setGirando(true); setSetorVez(null); startRef.current = null;
    const dur = 4000;
    const animar = (ts) => {
      if (!startRef.current) startRef.current = ts;
      const prog = Math.min((ts-startRef.current)/dur, 1);
      const ease = 1 - Math.pow(1-prog, 4);
      setAngulo(ease*alvo);
      if (prog < 1) { animRef.current = requestAnimationFrame(animar); return; }
      setGirando(false);
      setSetorVez(setorObj);
      const novoRes = [...resultados, { nome:atual, setor:sorteado.setor, setorNome:sorteado.nome, cor:sorteado.cor }];
      setResultados(novoRes);
      if (vez+1 >= garcons.length) setTela("resultado");
      else setTimeout(() => { setVez(v => v+1); setSetorVez(null); }, 1800);
    };
    animRef.current = requestAnimationFrame(animar);
  };

  useEffect(() => () => cancelAnimationFrame(animRef.current), []);

  const confirmarEscala = () => {
    const nova = { ...(escalaData||{}), [dia]: { ...((escalaData||{})[dia]||{}) } };
    cfg.fixos.forEach(f => { nova[dia][f.setor] = f.garcons.join(", "); });
    resultados.forEach(r => {
      const fp = cfg.fixos.find(f => f.setor === r.setor && f.parcial);
      if (fp) nova[dia][r.setor] = [...fp.garcons, r.nome].join(", ");
      else nova[dia][r.setor] = nova[dia][r.setor] ? nova[dia][r.setor]+", "+r.nome : r.nome;
    });
    onSalvarEscala(nova);
    setConfirmado(true);
  };

  const CardFixo = ({ f, sorteado }) => {
    const todos = f.parcial && sorteado ? [...f.garcons, sorteado.nome] : f.garcons;
    return (
      <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",background:f.cor+"12",borderRadius:10,border:`1px solid ${f.cor}30`}}>
        <div style={{width:11,height:11,borderRadius:3,background:f.cor,flexShrink:0}}/>
        <span style={{color:T.text,fontSize:13,fontWeight:700,flex:1}}>{f.nome}</span>
        <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
          {todos.map((g,i) => <span key={i} style={{background:f.cor,color:"#fff",fontSize:11,fontWeight:700,padding:"2px 9px",borderRadius:99}}>{g}</span>)}
          {f.parcial && !sorteado && <span style={{color:T.muted,fontSize:11,fontStyle:"italic",alignSelf:"center"}}>+ sorteado</span>}
        </div>
      </div>
    );
  };

  // ── TELA 1: FIXOS ──────────────────────────────────────────────────────────
  if (tela === "fixos") return (
    <div>
      <div style={{display:"flex",gap:8,marginBottom:16}}>
        {[{key:"sab",lbl:"⚡ Sábado"},{key:"dom",lbl:"🌞 Domingo"}].map(d => (
          <button key={d.key} onClick={() => reiniciar(d.key)}
            style={{padding:"8px 18px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:700,fontSize:13,background:dia===d.key?T.btn:T.btnOff,color:dia===d.key?T.btnText:T.btnOffText}}>
            {d.lbl}
          </button>
        ))}
      </div>

      <div style={{background:T.card,borderRadius:14,padding:"16px",marginBottom:12,border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
        <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1,margin:"0 0 12px"}}>🔒 Escalados fixos</p>
        <div style={{display:"flex",flexDirection:"column",gap:7}}>
          {cfg.fixos.map(f => <CardFixo key={f.setor} f={f} sorteado={null}/>)}
          {cfg.fechados.map(f => (
            <div key={f.setor} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",background:"#f1f5f9",borderRadius:10,border:"1px solid #e2e8f0"}}>
              <div style={{width:11,height:11,borderRadius:3,background:"#94a3b8",flexShrink:0}}/>
              <span style={{color:T.muted,fontSize:13,fontWeight:600,flex:1}}>{f.nome}</span>
              <span style={{color:"#94a3b8",fontSize:12,fontWeight:600}}>🚫 Fechado</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{background:T.card,borderRadius:14,padding:"16px",marginBottom:16,border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
        <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1,margin:"0 0 10px"}}>🎡 Vão sortear</p>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>
          {garcons.map(g => (
            <span key={g} style={{background:T.btn,color:"#fff",fontSize:12,fontWeight:700,padding:"5px 13px",borderRadius:99}}>{g}</span>
          ))}
        </div>
        <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1,margin:"0 0 8px"}}>Setores em disputa</p>
        <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
          {cfg.sorteioSetores.map(s => (
            <span key={s.setor} style={{background:s.cor+"18",color:s.cor,fontSize:12,fontWeight:700,padding:"5px 12px",borderRadius:99,border:`1px solid ${s.cor}40`}}>
              {s.nome}{s.vagas>1?` (${s.vagas} vagas)`:""}
            </span>
          ))}
        </div>
      </div>

      <button onClick={() => setTela("girar")}
        style={{width:"100%",background:T.btn,border:"none",borderRadius:12,color:"#fff",fontSize:15,fontWeight:800,padding:"14px",cursor:"pointer",boxShadow:"0 4px 16px rgba(37,99,235,0.3)"}}>
        🎡 Iniciar roleta — {garcons.length} garçons
      </button>
    </div>
  );

  // ── TELA 2: GIRAR ──────────────────────────────────────────────────────────
  if (tela === "girar") return (
    <div>
      <div style={{background:T.card,borderRadius:12,padding:"11px 16px",marginBottom:12,border:`1px solid ${T.cardBorder}`,display:"flex",alignItems:"center",gap:12,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
        <div style={{width:44,height:44,borderRadius:99,background:T.btn,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <span style={{color:"#fff",fontSize:17,fontWeight:800}}>{atual?.[0]}</span>
        </div>
        <div style={{flex:1}}>
          <p style={{color:T.muted,fontSize:10,margin:"0 0 1px",textTransform:"uppercase"}}>Vez de girar</p>
          <p style={{color:T.text,fontSize:18,fontWeight:800,margin:0}}>{atual}</p>
        </div>
        <div style={{textAlign:"right"}}>
          <p style={{color:T.muted,fontSize:10,margin:0}}>Rodada</p>
          <p style={{color:T.btn,fontSize:16,fontWeight:800,margin:0}}>{vez+1}/{garcons.length}</p>
        </div>
      </div>

      <div style={{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:12}}>
        <RoletaSVG setores={setoresRoleta} angulo={angulo}/>
        {setorVez && !girando && (
          <div style={{marginTop:12,background:setorVez.cor+"18",borderRadius:12,padding:"10px 24px",border:`2px solid ${setorVez.cor}`,textAlign:"center"}}>
            <p style={{color:T.muted,fontSize:10,margin:"0 0 2px"}}>🎯 {atual} ficou em...</p>
            <p style={{color:setorVez.cor,fontSize:22,fontWeight:800,margin:0}}>{setorVez.nome}!</p>
          </div>
        )}
        <button onClick={girar} disabled={girando}
          style={{marginTop:14,background:girando?"#94a3b8":T.btn,border:"none",borderRadius:12,color:"#fff",fontSize:16,fontWeight:800,padding:"13px 44px",cursor:girando?"not-allowed":"pointer",boxShadow:girando?"none":"0 4px 16px rgba(37,99,235,0.3)",transition:"all 0.2s"}}>
          {girando ? "🌀 Girando..." : "🎡 Girar!"}
        </button>
      </div>

      {resultados.length > 0 && (
        <div style={{background:T.card,borderRadius:12,padding:"12px 16px",marginBottom:12,border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 4px rgba(37,99,235,0.07)"}}>
          <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",margin:"0 0 8px",letterSpacing:1}}>🎯 Sorteados até agora</p>
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            {resultados.map((r,i) => (
              <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"7px 10px",background:r.cor+"12",borderRadius:9,border:`1px solid ${r.cor}30`}}>
                <div style={{width:9,height:9,borderRadius:3,background:r.cor}}/>
                <span style={{color:T.text,fontSize:12,fontWeight:700,flex:1}}>{r.nome}</span>
                <span style={{color:r.cor,fontSize:12,fontWeight:700}}>{r.setorNome}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {garcons.length - vez - 1 > 0 && !girando && (
        <div style={{background:T.card,borderRadius:10,padding:"10px 14px",border:`1px solid ${T.cardBorder}`,marginBottom:10}}>
          <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",margin:"0 0 7px"}}>Aguardando vez</p>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {garcons.slice(vez+1).map(p => (
              <span key={p} style={{background:T.btnOff,color:T.btnOffText,fontSize:11,fontWeight:600,padding:"4px 10px",borderRadius:99}}>{p}</span>
            ))}
          </div>
        </div>
      )}

      <button onClick={() => reiniciar(dia)}
        style={{width:"100%",background:T.btnOff,border:"none",borderRadius:10,color:T.btnOffText,fontSize:12,fontWeight:600,padding:"9px",cursor:"pointer"}}>
        ← Voltar para fixos
      </button>
    </div>
  );

  // ── TELA 3: RESULTADO FINAL ────────────────────────────────────────────────
  return (
    <div>
      <div style={{background:T.card,borderRadius:14,padding:"18px 16px",border:`2px solid ${T.gold}`,boxShadow:"0 4px 20px rgba(245,158,11,0.15)",marginBottom:12}}>
        <p style={{fontSize:32,textAlign:"center",margin:"0 0 4px"}}>🎉</p>
        <p style={{color:T.text,fontSize:16,fontWeight:800,margin:"0 0 16px",textAlign:"center"}}>Escala da semana!</p>

        <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1,margin:"0 0 8px"}}>🔒 Fixos</p>
        <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:14}}>
          {cfg.fixos.map(f => {
            const sorteado = resultados.find(r => r.setor === f.setor);
            return <CardFixo key={f.setor} f={f} sorteado={sorteado}/>;
          })}
          {cfg.fechados.map(f => (
            <div key={f.setor} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",background:"#f1f5f9",borderRadius:10,border:"1px solid #e2e8f0"}}>
              <div style={{width:11,height:11,borderRadius:3,background:"#94a3b8"}}/>
              <span style={{color:T.muted,fontSize:12,fontWeight:600,flex:1}}>{f.nome}</span>
              <span style={{color:"#94a3b8",fontSize:11}}>🚫 Fechado</span>
            </div>
          ))}
        </div>

        <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1,margin:"0 0 8px"}}>🎡 Sorteados</p>
        <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:16}}>
          {cfg.sorteioSetores.map(s => {
            const rs = resultados.filter(r => r.setor === s.setor);
            const fp = cfg.fixos.find(f => f.setor === s.setor && f.parcial);
            const todos = fp ? [...fp.garcons, ...rs.map(r=>r.nome)] : rs.map(r=>r.nome);
            if (!todos.length) return null;
            return (
              <div key={s.setor} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",background:s.cor+"12",borderRadius:10,border:`1px solid ${s.cor}30`}}>
                <div style={{width:11,height:11,borderRadius:3,background:s.cor}}/>
                <span style={{color:T.text,fontSize:13,fontWeight:700,flex:1}}>{s.nome.replace(" (+1)","")}</span>
                <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                  {todos.map((g,i) => <span key={i} style={{background:s.cor,color:"#fff",fontSize:11,fontWeight:700,padding:"2px 9px",borderRadius:99}}>{g}</span>)}
                </div>
              </div>
            );
          })}
        </div>

        {!confirmado ? (
          <button onClick={confirmarEscala}
            style={{width:"100%",background:T.green,border:"none",borderRadius:10,color:"#fff",fontSize:14,fontWeight:700,padding:"13px",cursor:"pointer",boxShadow:"0 2px 8px rgba(22,163,74,0.3)"}}>
            ✅ Confirmar e salvar escala
          </button>
        ) : (
          <div style={{background:T.greenBg,borderRadius:9,padding:"10px",textAlign:"center",border:`1px solid #86efac`}}>
            <span style={{color:T.greenText,fontSize:13,fontWeight:700}}>✅ Escala salva! Todos já podem ver.</span>
          </div>
        )}
      </div>

      <button onClick={() => reiniciar(dia)}
        style={{width:"100%",background:T.btnOff,border:"none",borderRadius:10,color:T.btnOffText,fontSize:12,fontWeight:600,padding:"10px",cursor:"pointer"}}>
        🔄 Novo sorteio
      </button>
    </div>
  );
}

// ─── EDITAR ESCALA (admin) ────────────────────────────────────────────────────
function AbaEscalaAdmin({ escalaData, onSalvar }) {
  const [dia, setDia] = useState("sab");
  const [escala, setEscala] = useState(escalaData || { sab:{}, dom:{} });
  const [salvo, setSalvo] = useState(false);

  useEffect(() => { if (escalaData) setEscala(escalaData); }, [escalaData]);

  const atualizar = (setorId, valor) => {
    const nova = { ...escala, [dia]: { ...escala[dia], [setorId]: valor } };
    setEscala(nova);
    onSalvar(nova);
    setSalvo(true);
    setTimeout(() => setSalvo(false), 2000);
  };

  return (
    <div>
      <p style={{color:T.muted, fontSize:12, marginBottom:12}}>
        Digite o nome de quem ficará em cada setor. Para 2 garçons, separe por vírgula (ex: <strong>Zé, LG</strong>).
      </p>

      <div style={{display:"flex", gap:8, marginBottom:14}}>
        {[{key:"sab",lbl:"⚡ Sábado"},{key:"dom",lbl:"🌞 Domingo"}].map(d=>(
          <button key={d.key} onClick={()=>setDia(d.key)}
            style={{padding:"8px 18px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:700,fontSize:13,
              background:dia===d.key?T.btn:T.btnOff, color:dia===d.key?T.btnText:T.btnOffText}}>
            {d.lbl}
          </button>
        ))}
      </div>

      {salvo && (
        <div style={{background:T.greenBg,color:T.greenText,fontSize:12,fontWeight:600,borderRadius:8,padding:"8px 14px",marginBottom:12,textAlign:"center"}}>
          ✅ Escala salva!
        </div>
      )}

      <div style={{display:"flex", flexDirection:"column", gap:10}}>
        {SETORES.map(s => {
          const val = escala[dia]?.[s.id] || "";
          return (
            <div key={s.id} style={{background:T.card, borderRadius:12, padding:"13px 16px",
              border:`1px solid ${val ? s.cor : T.cardBorder}`,
              boxShadow:"0 1px 4px rgba(37,99,235,0.07)", transition:"border 0.2s"}}>

              {/* Cabeçalho do setor */}
              <div style={{display:"flex", alignItems:"center", gap:8, marginBottom:8}}>
                <div style={{width:12, height:12, borderRadius:3, background:s.cor, flexShrink:0}}/>
                <span style={{color:T.text, fontSize:13, fontWeight:700, flex:1}}>{s.nome}</span>
                {s.fixo && <span style={{background:"#cffafe",color:"#0891b2",fontSize:9,fontWeight:700,padding:"2px 7px",borderRadius:99}}>🏨 Fixo</span>}
                <span style={{color:T.muted, fontSize:10}}>{s.mesas.length} mesas</span>
              </div>

              {/* Campo de edição */}
              <input
                value={val}
                onChange={e => atualizar(s.id, e.target.value)}
                placeholder={s.fixo ? "Richard, Silvia" : "Nome do garçom (ou dois nomes separados por vírgula)"}
                style={{
                  width:"100%", background:T.pageBg,
                  border:`1.5px solid ${val ? s.cor : T.cardBorder}`,
                  borderRadius:9, color:T.text, fontSize:14,
                  padding:"10px 13px", outline:"none", boxSizing:"border-box",
                  transition:"border 0.2s", fontFamily:"inherit"
                }}
              />

              {/* Tags dos garçons */}
              {val && (
                <div style={{display:"flex", gap:6, flexWrap:"wrap", marginTop:8}}>
                  {val.split(",").map(g=>g.trim()).filter(Boolean).map((g,i)=>(
                    <span key={i} style={{background:s.cor, color:"#fff", fontSize:12,
                      fontWeight:700, padding:"4px 12px", borderRadius:99}}>
                      {g}
                    </span>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}


export default function App() {
  const [modo, setModo] = useState(null);
  if (modo===null) return (
    <div style={{minHeight:"100vh",background:T.header,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Segoe UI',system-ui,sans-serif",flexDirection:"column",gap:16}}>
      <LogoSardao size={160} corLogo="#ffffff"/>
      <p style={{color:"rgba(255,255,255,0.6)",fontSize:12,margin:"-8px 0 0",letterSpacing:1}}>Painel de Metas 2026</p>
      <div style={{display:"flex",gap:12,marginTop:10}}>
        <button onClick={()=>setModo("view")} style={{background:"rgba(255,255,255,0.15)",border:"2px solid rgba(255,255,255,0.3)",borderRadius:10,color:"#fff",fontSize:14,fontWeight:600,padding:"12px 24px",cursor:"pointer"}}>👁 Visualizar</button>
        <button onClick={()=>setModo("login")} style={{background:"#fff",border:"none",borderRadius:10,color:T.text,fontSize:14,fontWeight:700,padding:"12px 24px",cursor:"pointer"}}>🔐 Admin</button>
      </div>
    </div>
  );
  if (modo==="login") return <LoginScreen onLogin={()=>setModo("admin")} />;
  return <Painel isAdmin={modo==="admin"} />;
}

// ─── SETORES ─────────────────────────────────────────────────────────────────
const SETORES = [
  { id:"salao",    nome:"Salão",        cor:"#7c3aed", corClara:"#ede9fe", mesas:[2,3,4,6,7,8,9,10,11,12,13,14], nivel:"⭐⭐⭐ Premium" },
  { id:"varanda",  nome:"Varanda",      cor:"#ca8a04", corClara:"#fef9c3", mesas:[15,16,18,19,20,21,22,23],      nivel:"⭐⭐⭐ Premium" },
  { id:"deckbar",  nome:"Deck Bar",     cor:"#dc2626", corClara:"#fee2e2", mesas:[30,31,32,33,34,35,36,37],      nivel:"⭐⭐⭐ Premium" },
  { id:"quadric",  nome:"Quadriculado", cor:"#78716c", corClara:"#f5f5f4", mesas:[42,43,44,45,46,47,48,49,50,51],nivel:"⭐⭐ Intermediário" },
  { id:"boqueta",  nome:"Boqueta",      cor:"#ea580c", corClara:"#ffedd5", mesas:[1,5,17,40,41],                 nivel:"⭐⭐ Intermediário" },
  { id:"paquinho", nome:"Deck Paquinho",cor:"#2563eb", corClara:"#dbeafe", mesas:[24,25,26,27,29],               nivel:"⭐ Fixo" },
  { id:"arvore",   nome:"Deck Árvore",  cor:"#16a34a", corClara:"#dcfce7", mesas:[54,55,56,57,58,59],            nivel:"⭐ Fixo" },
  { id:"pousada",  nome:"Pousada",      cor:"#0891b2", corClara:"#cffafe", mesas:[],                             nivel:"🏨 Fixo", fixo:true, fixoGarcons:["Richard","Silvia"] },
];

const SETORES_SORTEIO = SETORES.filter(s => !s.fixo);

const GARCONS_LISTA = ["Silvia","Felipe","Leandro","LG","Luís","Richard","Sarah","Sidmar","Zé","Thaís","Jocilene","Ale","Patrícia","Karen"];

function AbaSetores({ isAdmin, escalaData, fatSetorData, colabsAtivos, onSalvarEscala, onSalvarFat }) {
  const [subTab, setSubTab] = useState("mapa");
  const [dia, setDia] = useState("sab");
  const [setorSel, setSetorSel] = useState(null);
  const [semana, setSemana] = useState(0);

  const escala = escalaData || { dom:{}, sab:{} };

  // fatSetor: { semanas: [ { label:"01/07", sab:{salao:{Ze:4200,LG:3800}, varanda:{Luis:5100},...}, dom:{...} } ] }
  const fatSetor = fatSetorData || { semanas: [] };

  const semanaAtual = fatSetor.semanas[semana] || null;

  const setorAtual = SETORES.find(s => s.id === setorSel);

  const subBtn = (key, lbl) => (
    <button onClick={() => setSubTab(key)} style={{padding:"6px 12px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:11,background:subTab===key?T.btn:T.btnOff,color:subTab===key?T.btnText:T.btnOffText,whiteSpace:"nowrap"}}>{lbl}</button>
  );

  const BlocoSetor = ({ s }) => {
    const sel = setorSel === s.id;
    const garconsDia = (escala[dia]?.[s.id] || "—").split(", ");
    return (
      <div onClick={() => setSetorSel(sel ? null : s.id)}
        style={{flex:1,background:sel?s.cor:s.corClara,borderRadius:10,padding:"10px 8px",cursor:"pointer",border:`2px solid ${sel?s.cor:"transparent"}`,transition:"all 0.2s",minWidth:80}}>
        <p style={{color:sel?"#fff":s.cor,fontSize:10,fontWeight:700,margin:"0 0 4px",textAlign:"center"}}>{s.nome}</p>
        <div style={{display:"flex",flexWrap:"wrap",gap:2,justifyContent:"center",marginBottom:4}}>
          {s.mesas.slice(0,5).map(m=><span key={m} style={{background:sel?"rgba(255,255,255,0.2)":"rgba(0,0,0,0.08)",borderRadius:3,fontSize:7,padding:"1px 3px",color:sel?"#fff":s.cor}}>{m}</span>)}
          {s.mesas.length>5 && <span style={{fontSize:7,color:sel?"rgba(255,255,255,0.6)":T.muted}}>+{s.mesas.length-5}</span>}
        </div>
        {garconsDia.map((g,i)=><p key={i} style={{color:sel?"rgba(255,255,255,0.9)":T.muted,fontSize:9,textAlign:"center",margin:"1px 0 0"}}>{g}</p>)}
      </div>
    );
  };

  // Calcular ranking de setores a partir dos dados de faturamento
  const calcRankingSetores = (d) => {
    return SETORES.map(s => {
      let total = 0;
      const garcons = {};
      fatSetor.semanas.forEach(sem => {
        const dadosDia = sem[d]?.[s.id] || {};
        Object.entries(dadosDia).forEach(([g, v]) => {
          total += v;
          garcons[g] = (garcons[g] || 0) + v;
        });
      });
      return { ...s, total, garcons };
    }).sort((a,b) => b.total - a.total);
  };

  const rankingSab = calcRankingSetores("sab");
  const rankingDom = calcRankingSetores("dom");
  const maxSab = rankingSab[0]?.total || 1;
  const maxDom = rankingDom[0]?.total || 1;

  return (
    <div>
      <div style={{display:"flex",gap:7,marginBottom:14,flexWrap:"wrap"}}>
        {subBtn("mapa",    "🗺️ Mapa")}
        {subBtn("ranking", "📊 Faturamento")}
        {isAdmin && subBtn("lancar", "✏️ Lançar Vendas")}
      </div>

      {/* MAPA */}
      {subTab === "mapa" && (
        <div>
          <div style={{display:"flex",gap:8,marginBottom:10}}>
            {[{key:"sab",lbl:"⚡ Sábado"},{key:"dom",lbl:"🌞 Domingo"}].map(d=>(
              <button key={d.key} onClick={()=>setDia(d.key)} style={{padding:"6px 14px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:11,background:dia===d.key?T.btn:T.btnOff,color:dia===d.key?T.btnText:T.btnOffText}}>{d.lbl}</button>
            ))}
          </div>
          <div style={{background:T.card,borderRadius:14,padding:14,border:`1px solid ${T.cardBorder}`,boxShadow:"0 2px 8px rgba(37,99,235,0.08)",marginBottom:12}}>
            <p style={{color:T.muted,fontSize:10,textTransform:"uppercase",margin:"0 0 10px",letterSpacing:1}}>🏠 Toque num setor para ver detalhes</p>
            <div style={{display:"flex",flexDirection:"column",gap:7,maxWidth:600,margin:"0 auto"}}>
              <div style={{display:"flex",gap:7}}>
                <BlocoSetor s={SETORES.find(s=>s.id==="paquinho")} />
                <BlocoSetor s={SETORES.find(s=>s.id==="deckbar")} />
                <BlocoSetor s={SETORES.find(s=>s.id==="varanda")} />
              </div>
              <div style={{display:"flex",gap:7}}>
                <BlocoSetor s={SETORES.find(s=>s.id==="quadric")} />
                <BlocoSetor s={SETORES.find(s=>s.id==="salao")} />
              </div>
              <div style={{display:"flex",gap:7}}>
                <BlocoSetor s={SETORES.find(s=>s.id==="boqueta")} />
                <BlocoSetor s={SETORES.find(s=>s.id==="arvore")} />
              </div>
            </div>
          </div>

          {setorAtual && (
            <div style={{background:T.card,borderRadius:12,padding:"14px 16px",border:`2px solid ${setorAtual.cor}`}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
                <div style={{width:12,height:12,borderRadius:3,background:setorAtual.cor}}/>
                <h3 style={{color:T.text,fontSize:14,fontWeight:800,margin:0}}>{setorAtual.nome}</h3>
                <span style={{background:setorAtual.corClara,color:setorAtual.cor,fontSize:9,fontWeight:700,padding:"2px 8px",borderRadius:99}}>{setorAtual.nivel}</span>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
                <div>
                  <p style={{color:T.muted,fontSize:9,margin:"0 0 2px",textTransform:"uppercase"}}>⚡ Sábado</p>
                  {(escala.sab?.[setorAtual.id]||"—").split(", ").map((g,i)=><p key={i} style={{color:T.text,fontSize:13,fontWeight:700,margin:"1px 0"}}>{g}</p>)}
                </div>
                <div>
                  <p style={{color:T.muted,fontSize:9,margin:"0 0 2px",textTransform:"uppercase"}}>🌞 Domingo</p>
                  {(escala.dom?.[setorAtual.id]||"—").split(", ").map((g,i)=><p key={i} style={{color:T.text,fontSize:13,fontWeight:700,margin:"1px 0"}}>{g}</p>)}
                </div>
              </div>
              <div style={{background:setorAtual.corClara,borderRadius:8,padding:"8px 12px"}}>
                <p style={{color:setorAtual.cor,fontSize:10,margin:"0 0 2px",textTransform:"uppercase",fontWeight:700}}>Mesas ({setorAtual.mesas.length})</p>
                <p style={{color:T.text,fontSize:11,margin:0}}>{setorAtual.mesas.join(", ")}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FATURAMENTO POR SETOR */}
      {subTab === "ranking" && (
        <div>
          {fatSetor.semanas.length === 0 ? (
            <div style={{background:T.card,borderRadius:12,padding:"24px",textAlign:"center",border:`1px solid ${T.cardBorder}`}}>
              <p style={{fontSize:32,margin:"0 0 8px"}}>📊</p>
              <p style={{color:T.text,fontSize:14,fontWeight:700,margin:"0 0 4px"}}>Nenhuma venda lançada ainda</p>
              <p style={{color:T.muted,fontSize:12,margin:0}}>{isAdmin ? "Vá em ✏️ Lançar Vendas para registrar." : "A coordenação ainda não lançou os dados desta semana."}</p>
            </div>
          ) : (
            <div>
              {/* Seletor de semana */}
              {fatSetor.semanas.length > 1 && (
                <div style={{display:"flex",gap:6,marginBottom:12,flexWrap:"wrap"}}>
                  {fatSetor.semanas.map((sem,i)=>(
                    <button key={i} onClick={()=>setSemana(i)} style={{padding:"5px 12px",borderRadius:99,border:"none",cursor:"pointer",fontWeight:600,fontSize:11,background:semana===i?T.btn:T.btnOff,color:semana===i?T.btnText:T.btnOffText}}>
                      {sem.label}
                    </button>
                  ))}
                </div>
              )}

              {[{key:"sab",lbl:"⚡ Sábado",ranking:rankingSab,max:maxSab},{key:"dom",lbl:"🌞 Domingo",ranking:rankingDom,max:maxDom}].map(({key,lbl,ranking,max})=>(
                <div key={key} style={{marginBottom:16}}>
                  <p style={{color:T.text,fontSize:13,fontWeight:700,margin:"0 0 10px"}}>{lbl}</p>
                  <div style={{display:"flex",flexDirection:"column",gap:8}}>
                    {ranking.filter(s=>s.total>0).map((s,i)=>(
                      <div key={s.id} style={{background:T.card,borderRadius:12,padding:"12px 16px",border:i===0?`2px solid ${T.gold}`:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 3px rgba(37,99,235,0.07)"}}>
                        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                          <span style={{fontSize:i<3?18:12,minWidth:24,fontWeight:700,color:i>=3?T.muted:undefined}}>{["🥇","🥈","🥉"][i]||`${i+1}º`}</span>
                          <div style={{width:10,height:10,borderRadius:3,background:s.cor}}/>
                          <span style={{color:T.text,fontSize:13,fontWeight:700,flex:1}}>{s.nome}</span>
                          <span style={{color:s.cor,fontSize:14,fontWeight:800}}>{fmt(s.total)}</span>
                        </div>
                        <div style={{background:T.barBg,borderRadius:99,height:6,overflow:"hidden",marginBottom:8,marginLeft:34}}>
                          <div style={{height:"100%",width:`${(s.total/max)*100}%`,background:s.cor,borderRadius:99}}/>
                        </div>
                        {/* Garçons do setor */}
                        <div style={{display:"flex",gap:8,flexWrap:"wrap",paddingLeft:34}}>
                          {Object.entries(s.garcons).sort((a,b)=>b[1]-a[1]).map(([g,v])=>(
                            <div key={g} style={{background:s.corClara,borderRadius:8,padding:"4px 10px"}}>
                              <span style={{color:s.cor,fontSize:11,fontWeight:700}}>{g}</span>
                              <span style={{color:T.muted,fontSize:10}}> • {fmt(v)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                    {ranking.every(s=>s.total===0) && (
                      <p style={{color:T.muted,fontSize:12,textAlign:"center",padding:16}}>Sem dados para {lbl}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* LANÇAR VENDAS — só admin */}
      {subTab === "lancar" && isAdmin && (
        <LancarVendasSetor fatSetor={fatSetor} escala={escala} onSalvar={onSalvarFat} />
      )}
    </div>
  );
}

function LancarVendasSetor({ fatSetor, escala, onSalvar }) {
  const [dia, setDia] = useState("sab");
  const [labelSemana, setLabelSemana] = useState(() => {
    const hoje = new Date();
    return `${String(hoje.getDate()).padStart(2,"0")}/${String(hoje.getMonth()+1).padStart(2,"0")}`;
  });
  const [valores, setValores] = useState({});
  const [salvo, setSalvo] = useState(false);

  // Monta lista de garçons por setor baseado na escala
  const garconsPorSetor = (d) => {
    const res = {};
    SETORES.forEach(s => {
      const g = escala[d]?.[s.id];
      if (g && g !== "—") {
        res[s.id] = g.split(", ").filter(Boolean);
      }
    });
    return res;
  };

  const setValor = (setor, garcon, val) => {
    const num = parseFloat(String(val).replace(/\D/g,"")) || 0;
    setValores(prev => ({ ...prev, [`${dia}_${setor}_${garcon}`]: num }));
  };

  const getValor = (setor, garcon) => valores[`${dia}_${setor}_${garcon}`] || "";

  const salvarSemana = () => {
    const novasSemanas = [...(fatSetor.semanas || [])];
    const idx = novasSemanas.findIndex(s => s.label === labelSemana);
    
    const montarDia = (d) => {
      const gps = garconsPorSetor(d);
      const res = {};
      Object.entries(gps).forEach(([setor, garcons]) => {
        res[setor] = {};
        garcons.forEach(g => {
          const val = valores[`${d}_${setor}_${g}`] || 0;
          if (val > 0) res[setor][g] = val;
        });
      });
      return res;
    };

    const semanaObj = { label: labelSemana, sab: montarDia("sab"), dom: montarDia("dom") };

    if (idx >= 0) novasSemanas[idx] = semanaObj;
    else novasSemanas.push(semanaObj);

    onSalvar({ ...fatSetor, semanas: novasSemanas });
    setSalvo(true);
    setTimeout(() => setSalvo(false), 2500);
  };

  const inp = { width:"100%", background:T.pageBg, border:`1px solid ${T.cardBorder}`, borderRadius:7, color:T.text, fontSize:13, padding:"7px 10px", outline:"none", boxSizing:"border-box" };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
        <div>
          <p style={{color:T.muted,fontSize:10,margin:"0 0 3px",textTransform:"uppercase"}}>Semana (data)</p>
          <input value={labelSemana} onChange={e=>setLabelSemana(e.target.value)} style={inp} placeholder="Ex: 05/07" />
        </div>
        <div style={{display:"flex",alignItems:"flex-end"}}>
          <div style={{display:"flex",gap:7,width:"100%"}}>
            {[{key:"sab",lbl:"⚡ Sáb"},{key:"dom",lbl:"🌞 Dom"}].map(d=>(
              <button key={d.key} onClick={()=>setDia(d.key)} style={{flex:1,padding:"8px",borderRadius:9,border:"none",cursor:"pointer",fontWeight:600,fontSize:12,background:dia===d.key?T.btn:T.btnOff,color:dia===d.key?T.btnText:T.btnOffText}}>{d.lbl}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        {SETORES.map(s => {
          const garcons = garconsPorSetor(dia)[s.id] || [];
          if (garcons.length === 0) return null;
          return (
            <div key={s.id} style={{background:T.card,borderRadius:12,padding:"13px 16px",border:`1px solid ${T.cardBorder}`,boxShadow:"0 1px 3px rgba(37,99,235,0.07)"}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
                <div style={{width:10,height:10,borderRadius:3,background:s.cor}}/>
                <p style={{color:T.text,fontSize:13,fontWeight:700,margin:0}}>{s.nome}</p>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(160px,1fr))",gap:8}}>
                {garcons.map(g=>(
                  <div key={g}>
                    <p style={{color:s.cor,fontSize:10,margin:"0 0 3px",fontWeight:700}}>{g}</p>
                    <input value={getValor(s.id,g)} onChange={e=>setValor(s.id,g,e.target.value)} placeholder="R$ 0" style={inp} />
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <button onClick={salvarSemana} style={{width:"100%",marginTop:14,background:T.btn,border:"none",borderRadius:10,color:"#fff",fontSize:14,fontWeight:700,padding:"12px",cursor:"pointer"}}>
        💾 Salvar vendas da semana
      </button>
      {salvo && <div style={{background:T.greenBg,color:T.greenText,fontSize:12,fontWeight:600,borderRadius:8,padding:"8px",marginTop:8,textAlign:"center"}}>✅ Salvo! Garçons já podem visualizar.</div>}
    </div>
  );
}

